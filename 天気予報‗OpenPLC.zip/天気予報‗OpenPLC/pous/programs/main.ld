PROGRAM main
 VAR

    instFB_GetGamepad : FB_GetGamepad;
    TON0 : TON;
    TOF0 : TOF;

    isBlink : bool;
    btn_1 : BOOL;
    btn_2 : BOOL;
    lamp : BOOL;
    instGetWeather : FB_GetWeather;
    wetherID : UDINT := 250010;
    debg : BOOL;
    CurrentDT : DT;
    instUtcToJst : FB_UtcToJst;
    getFlag : BOOL;
    sec : INT;
    sec10 : INT;
    TON1 : TON;
    TOF1 : TOF;
    alwaysTrue : BOOL;
    isInitial : BOOL;
    TP0 : TP;
    TON2 : TON;
    preID : UDINT;
    isIdChange : BOOL;
END_VAR

var_external
    gAreaID : UDINT;
    gYear : INT;
    gMonth : INT;
    gDay : INT;
    gHour : INT;
    gMinute : INT;
    gWeek : INT;
    gWethCode : ARRAY[0..2] of UINT;
    gWethTemp : ARRAY[0..2] of INT;
    gWethRain : ARRAY[0..7] of INT;
    gFlicker : BOOL;
    gApiValid : BOOL;
    gApiError : BOOL;
end_var
  VAR_INPUT
  END_VAR

{
  "name": "main",
  "rungs": [
    {
      "id": "rung_main_bab68704-423e-4c54-8011-0b3f8ced5f29",
      "comment": "initial",
      "defaultBounds": [
        300,
        100
      ],
      "reactFlowViewport": [
        825,
        226
      ],
      "selectedNodes": [],
      "nodes": [
        {
          "id": "left-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2",
          "type": "powerRail",
          "position": {
            "x": 0,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 3,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "left-rail",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 20,
                "right": -3
              }
            },
            "numericId": "6798440",
            "variant": "left",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_OPEN_f6ff1220-5f7f-4483-998a-0fface7c53c5",
          "type": "parallel",
          "position": {
            "x": 23,
            "y": 49
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 23,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 23,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 23,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 50
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "3660478",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "input-top",
              "position": "top",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "output-down",
              "position": "bottom",
              "type": "source",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelCloseReference": "PARALLEL_CLOSE_f8061337-7409-4cdf-b44f-f73b57c99f09",
            "type": "open",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "COIL_60572fe9-6773-48b9-8ec2-489e18cc84ea",
          "type": "coil",
          "position": {
            "x": 72,
            "y": 38
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              },
              {
                "glbPosition": {
                  "x": 100,
                  "y": 50
                },
                "relPosition": {
                  "x": 28,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "variant": "default",
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 100,
                  "y": 50
                },
                "relPosition": {
                  "x": 28,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 72,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 12
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target",
              "style": {
                "left": -3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 100,
                "y": 50
              },
              "relPosition": {
                "x": 28,
                "y": 12
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source",
              "style": {
                "right": -3
              }
            },
            "numericId": "1277694",
            "variable": {
              "id": "4ff5f096-618c-441c-9798-65299bfe19f5",
              "name": "alwaysTrue",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 28,
          "height": 24,
          "measured": {
            "width": 28,
            "height": 24
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "BLOCK_00fc5c56-9999-4daa-9599-cb237852e0c1",
          "type": "block",
          "position": {
            "x": 147,
            "y": 106
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 147,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "IN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 147,
                  "y": 182
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "PT",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 213,
                  "y": 142
                },
                "relPosition": {
                  "x": 66,
                  "y": 36
                },
                "id": "Q",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 213,
                  "y": 182
                },
                "relPosition": {
                  "x": 66,
                  "y": 76
                },
                "id": "ET",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 147,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "IN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 147,
                  "y": 182
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "PT",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 213,
                  "y": 142
                },
                "relPosition": {
                  "x": 66,
                  "y": 36
                },
                "id": "Q",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 213,
                  "y": 182
                },
                "relPosition": {
                  "x": 66,
                  "y": 76
                },
                "id": "ET",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 147,
                "y": 142
              },
              "relPosition": {
                "x": 0,
                "y": 36
              },
              "id": "IN",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 36,
                "left": 0
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 213,
                "y": 142
              },
              "relPosition": {
                "x": 66,
                "y": 36
              },
              "id": "Q",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 36,
                "right": 0
              }
            },
            "numericId": "6649232",
            "variant": {
              "name": "TON",
              "type": "function-block",
              "language": "st",
              "variables": [
                {
                  "name": "IN",
                  "class": "input",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "PT",
                  "class": "input",
                  "type": {
                    "definition": "base-type",
                    "value": "TIME"
                  }
                },
                {
                  "name": "Q",
                  "class": "output",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "ET",
                  "class": "output",
                  "type": {
                    "definition": "base-type",
                    "value": "TIME"
                  }
                }
              ],
              "body": "",
              "documentation": "The on-delay timer can be used to delay setting an output true, for fixed period after an input becomes true."
            },
            "variable": {
              "id": "1e76a26a-6bc9-4f13-b427-8b1fddff1c23",
              "name": "TON2",
              "type": {
                "definition": "derived",
                "value": "TON"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "executionControl": false,
            "lockExecutionControl": false,
            "connectedVariables": [
              {
                "handleId": "PT",
                "type": "input",
                "variable": {
                  "name": "T#1s"
                }
              }
            ],
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 66,
          "height": 100,
          "measured": {
            "width": 66,
            "height": 100
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "BLOCK_c4dcb6e9-db69-4b31-b612-470c52d68bc9",
          "type": "block",
          "position": {
            "x": 453,
            "y": 106
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 453,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "IN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 453,
                  "y": 182
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "PT",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 519,
                  "y": 142
                },
                "relPosition": {
                  "x": 66,
                  "y": 36
                },
                "id": "Q",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 519,
                  "y": 182
                },
                "relPosition": {
                  "x": 66,
                  "y": 76
                },
                "id": "ET",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 453,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "IN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 453,
                  "y": 182
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "PT",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 519,
                  "y": 142
                },
                "relPosition": {
                  "x": 66,
                  "y": 36
                },
                "id": "Q",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 519,
                  "y": 182
                },
                "relPosition": {
                  "x": 66,
                  "y": 76
                },
                "id": "ET",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 453,
                "y": 142
              },
              "relPosition": {
                "x": 0,
                "y": 36
              },
              "id": "IN",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 36,
                "left": 0
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 519,
                "y": 142
              },
              "relPosition": {
                "x": 66,
                "y": 36
              },
              "id": "Q",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 36,
                "right": 0
              }
            },
            "numericId": "2535564",
            "variant": {
              "name": "TP",
              "type": "function-block",
              "language": "st",
              "variables": [
                {
                  "name": "IN",
                  "class": "input",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "PT",
                  "class": "input",
                  "type": {
                    "definition": "base-type",
                    "value": "TIME"
                  }
                },
                {
                  "name": "Q",
                  "class": "output",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "ET",
                  "class": "output",
                  "type": {
                    "definition": "base-type",
                    "value": "TIME"
                  }
                }
              ],
              "body": "",
              "documentation": "The pulse timer can be used to generate output pulses of a given time duration."
            },
            "variable": {
              "id": "3e41d198-be88-4ecb-bda6-4f03c6b9d057",
              "name": "TP0",
              "type": {
                "definition": "derived",
                "value": "TP"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "executionControl": false,
            "lockExecutionControl": false,
            "connectedVariables": [
              {
                "handleId": "PT",
                "type": "input",
                "variable": {
                  "name": "T#10s"
                }
              }
            ],
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 66,
          "height": 100,
          "measured": {
            "width": 66,
            "height": 100
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "COIL_d556d1ab-232b-4e4d-9481-4420ace350fe",
          "type": "coil",
          "position": {
            "x": 684,
            "y": 130
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 684,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              },
              {
                "glbPosition": {
                  "x": 712,
                  "y": 142
                },
                "relPosition": {
                  "x": 28,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "variant": "default",
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 684,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 712,
                  "y": 142
                },
                "relPosition": {
                  "x": 28,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 684,
                "y": 142
              },
              "relPosition": {
                "x": 0,
                "y": 12
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target",
              "style": {
                "left": -3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 712,
                "y": 142
              },
              "relPosition": {
                "x": 28,
                "y": 12
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source",
              "style": {
                "right": -3
              }
            },
            "numericId": "3291166",
            "variable": {
              "id": "",
              "name": "isInitial",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 28,
          "height": 24,
          "measured": {
            "width": 28,
            "height": 24
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_CLOSE_f8061337-7409-4cdf-b44f-f73b57c99f09",
          "type": "parallel",
          "position": {
            "x": 757,
            "y": 49
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 757,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 761,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              },
              {
                "glbPosition": {
                  "x": 761,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 761,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 757,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 761,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 761,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 761,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 757,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 761,
                "y": 50
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "8126712",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 761,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "input-down",
              "position": "bottom",
              "type": "target",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 761,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "output-top",
              "position": "top",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOpenReference": "PARALLEL_OPEN_f6ff1220-5f7f-4483-998a-0fface7c53c5",
            "type": "close",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "right-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2",
          "type": "powerRail",
          "position": {
            "x": 822,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                },
                "x": 822
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                },
                "x": 297
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 297,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "right-rail",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 20,
                "left": -3
              }
            },
            "numericId": "912023",
            "variant": "right",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_f40da30e-591b-4438-8cd1-338f6865d561",
          "type": "variable",
          "position": {
            "x": 37,
            "y": 166
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 197,
                  "y": 182
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 197,
                  "y": 182
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 197,
                "y": 182
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "7789752",
            "variable": {
              "name": "T#1s"
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_00fc5c56-9999-4daa-9599-cb237852e0c1",
              "handleId": "PT",
              "variableType": {
                "name": "PT",
                "class": "input",
                "type": {
                  "definition": "base-type",
                  "value": "TIME"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_add92e39-a23c-4769-ac40-ef580aae8b4b",
          "type": "variable",
          "position": {
            "x": 243,
            "y": 166
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 243,
                  "y": 182
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 243,
                  "y": 182
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 243,
                "y": 182
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "648865",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_00fc5c56-9999-4daa-9599-cb237852e0c1",
              "handleId": "ET",
              "variableType": {
                "name": "ET",
                "class": "output",
                "type": {
                  "definition": "base-type",
                  "value": "TIME"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_3b758493-a287-49ee-8d3e-646f6a5b2b59",
          "type": "variable",
          "position": {
            "x": 343,
            "y": 166
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 503,
                  "y": 182
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 503,
                  "y": 182
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 503,
                "y": 182
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "6026979",
            "variable": {
              "name": "T#10s"
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_c4dcb6e9-db69-4b31-b612-470c52d68bc9",
              "handleId": "PT",
              "variableType": {
                "name": "PT",
                "class": "input",
                "type": {
                  "definition": "base-type",
                  "value": "TIME"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_6cd7370e-55e5-4c8a-afd4-0d1ee018da05",
          "type": "variable",
          "position": {
            "x": 549,
            "y": 166
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 549,
                  "y": 182
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 549,
                  "y": 182
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 549,
                "y": 182
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "7072845",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_c4dcb6e9-db69-4b31-b612-470c52d68bc9",
              "handleId": "ET",
              "variableType": {
                "name": "ET",
                "class": "output",
                "type": {
                  "definition": "base-type",
                  "value": "TIME"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        }
      ],
      "edges": [
        {
          "id": "e_left-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2_PARALLEL_OPEN_f6ff1220-5f7f-4483-998a-0fface7c53c5__left-rail_input",
          "source": "left-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2",
          "target": "PARALLEL_OPEN_f6ff1220-5f7f-4483-998a-0fface7c53c5",
          "sourceHandle": "left-rail",
          "targetHandle": "input"
        },
        {
          "id": "e_PARALLEL_OPEN_f6ff1220-5f7f-4483-998a-0fface7c53c5_COIL_60572fe9-6773-48b9-8ec2-489e18cc84ea__output-right_input",
          "source": "PARALLEL_OPEN_f6ff1220-5f7f-4483-998a-0fface7c53c5",
          "target": "COIL_60572fe9-6773-48b9-8ec2-489e18cc84ea",
          "sourceHandle": "output-right",
          "targetHandle": "input"
        },
        {
          "id": "e_COIL_60572fe9-6773-48b9-8ec2-489e18cc84ea_PARALLEL_CLOSE_f8061337-7409-4cdf-b44f-f73b57c99f09__output_input",
          "source": "COIL_60572fe9-6773-48b9-8ec2-489e18cc84ea",
          "target": "PARALLEL_CLOSE_f8061337-7409-4cdf-b44f-f73b57c99f09",
          "sourceHandle": "output",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_c4dcb6e9-db69-4b31-b612-470c52d68bc9_COIL_d556d1ab-232b-4e4d-9481-4420ace350fe__???_input",
          "source": "BLOCK_c4dcb6e9-db69-4b31-b612-470c52d68bc9",
          "target": "COIL_d556d1ab-232b-4e4d-9481-4420ace350fe",
          "sourceHandle": "Q",
          "targetHandle": "input"
        },
        {
          "id": "e_COIL_d556d1ab-232b-4e4d-9481-4420ace350fe_PARALLEL_CLOSE_f8061337-7409-4cdf-b44f-f73b57c99f09__output_input-down",
          "source": "COIL_d556d1ab-232b-4e4d-9481-4420ace350fe",
          "target": "PARALLEL_CLOSE_f8061337-7409-4cdf-b44f-f73b57c99f09",
          "sourceHandle": "output",
          "targetHandle": "input-down"
        },
        {
          "id": "e_PARALLEL_CLOSE_f8061337-7409-4cdf-b44f-f73b57c99f09_right-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2__output-right_right-rail",
          "source": "PARALLEL_CLOSE_f8061337-7409-4cdf-b44f-f73b57c99f09",
          "target": "right-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2",
          "sourceHandle": "output-right",
          "targetHandle": "right-rail"
        },
        {
          "id": "e_PARALLEL_OPEN_f6ff1220-5f7f-4483-998a-0fface7c53c5_BLOCK_00fc5c56-9999-4daa-9599-cb237852e0c1__output-down_???",
          "source": "PARALLEL_OPEN_f6ff1220-5f7f-4483-998a-0fface7c53c5",
          "target": "BLOCK_00fc5c56-9999-4daa-9599-cb237852e0c1",
          "sourceHandle": "output-down",
          "targetHandle": "IN"
        },
        {
          "id": "e_BLOCK_00fc5c56-9999-4daa-9599-cb237852e0c1_BLOCK_c4dcb6e9-db69-4b31-b612-470c52d68bc9__???_IN",
          "source": "BLOCK_00fc5c56-9999-4daa-9599-cb237852e0c1",
          "target": "BLOCK_c4dcb6e9-db69-4b31-b612-470c52d68bc9",
          "sourceHandle": "Q",
          "targetHandle": "IN"
        },
        {
          "id": "e_VARIABLE_f40da30e-591b-4438-8cd1-338f6865d561_BLOCK_00fc5c56-9999-4daa-9599-cb237852e0c1__output_PT",
          "source": "VARIABLE_f40da30e-591b-4438-8cd1-338f6865d561",
          "target": "BLOCK_00fc5c56-9999-4daa-9599-cb237852e0c1",
          "sourceHandle": "output",
          "targetHandle": "PT"
        },
        {
          "id": "e_BLOCK_00fc5c56-9999-4daa-9599-cb237852e0c1_VARIABLE_add92e39-a23c-4769-ac40-ef580aae8b4b__ET_input",
          "source": "BLOCK_00fc5c56-9999-4daa-9599-cb237852e0c1",
          "target": "VARIABLE_add92e39-a23c-4769-ac40-ef580aae8b4b",
          "sourceHandle": "ET",
          "targetHandle": "input"
        },
        {
          "id": "e_VARIABLE_3b758493-a287-49ee-8d3e-646f6a5b2b59_BLOCK_c4dcb6e9-db69-4b31-b612-470c52d68bc9__output_PT",
          "source": "VARIABLE_3b758493-a287-49ee-8d3e-646f6a5b2b59",
          "target": "BLOCK_c4dcb6e9-db69-4b31-b612-470c52d68bc9",
          "sourceHandle": "output",
          "targetHandle": "PT"
        },
        {
          "id": "e_BLOCK_c4dcb6e9-db69-4b31-b612-470c52d68bc9_VARIABLE_6cd7370e-55e5-4c8a-afd4-0d1ee018da05__ET_input",
          "source": "BLOCK_c4dcb6e9-db69-4b31-b612-470c52d68bc9",
          "target": "VARIABLE_6cd7370e-55e5-4c8a-afd4-0d1ee018da05",
          "sourceHandle": "ET",
          "targetHandle": "input"
        }
      ],
      "handleBranches": []
    },
    {
      "id": "rung_main_289721dd-14e6-4190-9114-fb4592d53122",
      "comment": "flicker",
      "defaultBounds": [
        300,
        100
      ],
      "reactFlowViewport": [
        935,
        134
      ],
      "selectedNodes": [],
      "nodes": [
        {
          "id": "left-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2",
          "type": "powerRail",
          "position": {
            "x": 0,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 3,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "left-rail",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 20,
                "right": -3
              }
            },
            "numericId": "1605919",
            "variant": "left",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "CONTACT_ec383abc-17aa-42dd-8394-d7c63fc9d7b3",
          "type": "contact",
          "position": {
            "x": 68,
            "y": 38
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 68,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              },
              {
                "glbPosition": {
                  "x": 92,
                  "y": 50
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "variant": "negated",
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 68,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 92,
                  "y": 50
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 68,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 12
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target",
              "style": {
                "left": -3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 92,
                "y": 50
              },
              "relPosition": {
                "x": 24,
                "y": 12
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source",
              "style": {
                "right": -3
              }
            },
            "numericId": "6755676",
            "variable": {
              "name": "isBlink"
            },
            "executionOrder": 0,
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 24,
          "height": 24,
          "measured": {
            "width": 24,
            "height": 24
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "BLOCK_a233116c-52ce-48fb-8030-b2b962988f79",
          "type": "block",
          "position": {
            "x": 257,
            "y": 14
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 257,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "IN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 257,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "PT",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 323,
                  "y": 50
                },
                "relPosition": {
                  "x": 66,
                  "y": 36
                },
                "id": "Q",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 323,
                  "y": 90
                },
                "relPosition": {
                  "x": 66,
                  "y": 76
                },
                "id": "ET",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 257,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "IN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 257,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "PT",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 323,
                  "y": 50
                },
                "relPosition": {
                  "x": 66,
                  "y": 36
                },
                "id": "Q",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 323,
                  "y": 90
                },
                "relPosition": {
                  "x": 66,
                  "y": 76
                },
                "id": "ET",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 257,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 36
              },
              "id": "IN",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 36,
                "left": 0
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 323,
                "y": 50
              },
              "relPosition": {
                "x": 66,
                "y": 36
              },
              "id": "Q",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 36,
                "right": 0
              }
            },
            "numericId": "8885064",
            "variant": {
              "name": "TON",
              "type": "function-block",
              "variables": [
                {
                  "name": "IN",
                  "class": "input",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "PT",
                  "class": "input",
                  "type": {
                    "definition": "base-type",
                    "value": "TIME"
                  }
                },
                {
                  "name": "Q",
                  "class": "output",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "ET",
                  "class": "output",
                  "type": {
                    "definition": "base-type",
                    "value": "TIME"
                  }
                }
              ],
              "documentation": "The on-delay timer can be used to delay setting an output true, for fixed period after an input becomes true.",
              "extensible": false
            },
            "variable": {
              "id": "94307d6e-3793-4173-bc7e-59a15bbd258f",
              "name": "TON1",
              "type": {
                "definition": "derived",
                "value": "TON"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "executionControl": false,
            "lockExecutionControl": false,
            "connectedVariables": [
              {
                "handleId": "PT",
                "type": "input",
                "variable": {
                  "name": "T#100ms"
                }
              }
            ],
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 66,
          "height": 100,
          "measured": {
            "width": 66,
            "height": 100
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "BLOCK_46f1508d-3c97-455a-a2f1-a3c92d4858af",
          "type": "block",
          "position": {
            "x": 563,
            "y": 14
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 563,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "IN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 563,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "PT",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 629,
                  "y": 50
                },
                "relPosition": {
                  "x": 66,
                  "y": 36
                },
                "id": "Q",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 629,
                  "y": 90
                },
                "relPosition": {
                  "x": 66,
                  "y": 76
                },
                "id": "ET",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 563,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "IN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 563,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "PT",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 629,
                  "y": 50
                },
                "relPosition": {
                  "x": 66,
                  "y": 36
                },
                "id": "Q",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 629,
                  "y": 90
                },
                "relPosition": {
                  "x": 66,
                  "y": 76
                },
                "id": "ET",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 563,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 36
              },
              "id": "IN",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 36,
                "left": 0
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 629,
                "y": 50
              },
              "relPosition": {
                "x": 66,
                "y": 36
              },
              "id": "Q",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 36,
                "right": 0
              }
            },
            "numericId": "1877840",
            "variant": {
              "name": "TOF",
              "type": "function-block",
              "variables": [
                {
                  "name": "IN",
                  "class": "input",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "PT",
                  "class": "input",
                  "type": {
                    "definition": "base-type",
                    "value": "TIME"
                  }
                },
                {
                  "name": "Q",
                  "class": "output",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "ET",
                  "class": "output",
                  "type": {
                    "definition": "base-type",
                    "value": "TIME"
                  }
                }
              ],
              "documentation": "The off-delay timer can be used to delay setting an output false, for fixed period after input goes false.",
              "extensible": false
            },
            "variable": {
              "id": "577a41ac-f946-40d1-9d26-c3f1b120a570",
              "name": "TOF1",
              "type": {
                "definition": "derived",
                "value": "TOF"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "executionControl": false,
            "lockExecutionControl": false,
            "connectedVariables": [
              {
                "handleId": "PT",
                "type": "input",
                "variable": {
                  "name": "T#100ms"
                }
              }
            ],
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 66,
          "height": 100,
          "measured": {
            "width": 66,
            "height": 100
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "COIL_6afdd2ed-4d61-4727-8b49-2073c8aa5d6f",
          "type": "coil",
          "position": {
            "x": 794,
            "y": 38
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 794,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              },
              {
                "glbPosition": {
                  "x": 822,
                  "y": 50
                },
                "relPosition": {
                  "x": 28,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "variant": "default",
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 794,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 822,
                  "y": 50
                },
                "relPosition": {
                  "x": 28,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 794,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 12
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target",
              "style": {
                "left": -3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 822,
                "y": 50
              },
              "relPosition": {
                "x": 28,
                "y": 12
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source",
              "style": {
                "right": -3
              }
            },
            "numericId": "3225856",
            "variable": {
              "name": "isBlink"
            },
            "executionOrder": 0,
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 28,
          "height": 24,
          "measured": {
            "width": 28,
            "height": 24
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "right-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2",
          "type": "powerRail",
          "position": {
            "x": 932,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                },
                "x": 932
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                },
                "x": 932
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 297,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "right-rail",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 20,
                "left": -3
              }
            },
            "numericId": "5885504",
            "variant": "right",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_ac8520d1-711c-46df-89cd-04a5dcef8443",
          "type": "variable",
          "position": {
            "x": 147,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 307,
                  "y": 90
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 307,
                  "y": 90
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 307,
                "y": 90
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "9804134",
            "variable": {
              "name": "T#100ms"
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_a233116c-52ce-48fb-8030-b2b962988f79",
              "handleId": "PT",
              "variableType": {
                "name": "PT",
                "class": "input",
                "type": {
                  "definition": "base-type",
                  "value": "TIME"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_9bf8576f-4730-4e04-9b4f-c78f0a0c5fd4",
          "type": "variable",
          "position": {
            "x": 353,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 353,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 353,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 353,
                "y": 90
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "6378330",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_a233116c-52ce-48fb-8030-b2b962988f79",
              "handleId": "ET",
              "variableType": {
                "name": "ET",
                "class": "output",
                "type": {
                  "definition": "base-type",
                  "value": "TIME"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_0fe577dc-7f65-468a-bd58-e8bdecd000b6",
          "type": "variable",
          "position": {
            "x": 453,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 613,
                  "y": 90
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 613,
                  "y": 90
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 613,
                "y": 90
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "5335022",
            "variable": {
              "name": "T#100ms"
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_46f1508d-3c97-455a-a2f1-a3c92d4858af",
              "handleId": "PT",
              "variableType": {
                "name": "PT",
                "class": "input",
                "type": {
                  "definition": "base-type",
                  "value": "TIME"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_10857575-4699-4fdf-8f91-5ac07fb08b4c",
          "type": "variable",
          "position": {
            "x": 659,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 659,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 659,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 659,
                "y": 90
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "345115",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_46f1508d-3c97-455a-a2f1-a3c92d4858af",
              "handleId": "ET",
              "variableType": {
                "name": "ET",
                "class": "output",
                "type": {
                  "definition": "base-type",
                  "value": "TIME"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        }
      ],
      "edges": [
        {
          "id": "e_BLOCK_a233116c-52ce-48fb-8030-b2b962988f79_BLOCK_46f1508d-3c97-455a-a2f1-a3c92d4858af__Q_IN",
          "source": "BLOCK_a233116c-52ce-48fb-8030-b2b962988f79",
          "target": "BLOCK_46f1508d-3c97-455a-a2f1-a3c92d4858af",
          "sourceHandle": "Q",
          "targetHandle": "IN"
        },
        {
          "id": "e_BLOCK_46f1508d-3c97-455a-a2f1-a3c92d4858af_COIL_6afdd2ed-4d61-4727-8b49-2073c8aa5d6f__Q_input",
          "source": "BLOCK_46f1508d-3c97-455a-a2f1-a3c92d4858af",
          "target": "COIL_6afdd2ed-4d61-4727-8b49-2073c8aa5d6f",
          "sourceHandle": "Q",
          "targetHandle": "input"
        },
        {
          "id": "e_COIL_6afdd2ed-4d61-4727-8b49-2073c8aa5d6f_right-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2__output_right-rail",
          "source": "COIL_6afdd2ed-4d61-4727-8b49-2073c8aa5d6f",
          "target": "right-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2",
          "sourceHandle": "output",
          "targetHandle": "right-rail"
        },
        {
          "id": "e_left-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2_CONTACT_ec383abc-17aa-42dd-8394-d7c63fc9d7b3__left-rail_input",
          "source": "left-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2",
          "target": "CONTACT_ec383abc-17aa-42dd-8394-d7c63fc9d7b3",
          "sourceHandle": "left-rail",
          "targetHandle": "input"
        },
        {
          "id": "e_CONTACT_ec383abc-17aa-42dd-8394-d7c63fc9d7b3_BLOCK_a233116c-52ce-48fb-8030-b2b962988f79__output_IN",
          "source": "CONTACT_ec383abc-17aa-42dd-8394-d7c63fc9d7b3",
          "target": "BLOCK_a233116c-52ce-48fb-8030-b2b962988f79",
          "sourceHandle": "output",
          "targetHandle": "IN"
        },
        {
          "id": "e_VARIABLE_ac8520d1-711c-46df-89cd-04a5dcef8443_BLOCK_a233116c-52ce-48fb-8030-b2b962988f79__output_PT",
          "source": "VARIABLE_ac8520d1-711c-46df-89cd-04a5dcef8443",
          "target": "BLOCK_a233116c-52ce-48fb-8030-b2b962988f79",
          "sourceHandle": "output",
          "targetHandle": "PT"
        },
        {
          "id": "e_BLOCK_a233116c-52ce-48fb-8030-b2b962988f79_VARIABLE_9bf8576f-4730-4e04-9b4f-c78f0a0c5fd4__ET_input",
          "source": "BLOCK_a233116c-52ce-48fb-8030-b2b962988f79",
          "target": "VARIABLE_9bf8576f-4730-4e04-9b4f-c78f0a0c5fd4",
          "sourceHandle": "ET",
          "targetHandle": "input"
        },
        {
          "id": "e_VARIABLE_0fe577dc-7f65-468a-bd58-e8bdecd000b6_BLOCK_46f1508d-3c97-455a-a2f1-a3c92d4858af__output_PT",
          "source": "VARIABLE_0fe577dc-7f65-468a-bd58-e8bdecd000b6",
          "target": "BLOCK_46f1508d-3c97-455a-a2f1-a3c92d4858af",
          "sourceHandle": "output",
          "targetHandle": "PT"
        },
        {
          "id": "e_BLOCK_46f1508d-3c97-455a-a2f1-a3c92d4858af_VARIABLE_10857575-4699-4fdf-8f91-5ac07fb08b4c__ET_input",
          "source": "BLOCK_46f1508d-3c97-455a-a2f1-a3c92d4858af",
          "target": "VARIABLE_10857575-4699-4fdf-8f91-5ac07fb08b4c",
          "sourceHandle": "ET",
          "targetHandle": "input"
        }
      ],
      "handleBranches": []
    },
    {
      "id": "rung_main_2776776c-b03b-4df7-aac0-6348c86dbffd",
      "comment": "自己保持(動作テスト)",
      "defaultBounds": [
        300,
        100
      ],
      "reactFlowViewport": [
        445,
        174
      ],
      "nodes": [
        {
          "id": "left-rail-rung_main_2776776c-b03b-4df7-aac0-6348c86dbffd",
          "type": "powerRail",
          "position": {
            "x": 0,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 3,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "left-rail",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 20,
                "right": -3
              }
            },
            "numericId": "5351439",
            "variant": "left",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_OPEN_526aa7e5-b3ad-4e57-a0ea-1900531f9022",
          "type": "parallel",
          "position": {
            "x": 23,
            "y": 49
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 23,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 23,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 23,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 50
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "2391383",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "input-top",
              "position": "top",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "output-down",
              "position": "bottom",
              "type": "source",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelCloseReference": "PARALLEL_CLOSE_0b1455e3-6a1e-4fa1-aae2-4ed4acc626ef",
            "type": "open",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "CONTACT_724a8c06-e80c-4edc-90b0-3f2f640be7e2",
          "type": "contact",
          "position": {
            "x": 72,
            "y": 38
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              },
              {
                "glbPosition": {
                  "x": 96,
                  "y": 50
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "variant": "default",
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 96,
                  "y": 50
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 72,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 12
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target",
              "style": {
                "left": -3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 96,
                "y": 50
              },
              "relPosition": {
                "x": 24,
                "y": 12
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source",
              "style": {
                "right": -3
              }
            },
            "numericId": "3091103",
            "variable": {
              "id": "",
              "name": "btn_1",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 24,
          "height": 24,
          "measured": {
            "width": 24,
            "height": 24
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "CONTACT_25607947-3349-4b9d-aad9-489b9b00d578",
          "type": "contact",
          "position": {
            "x": 72,
            "y": 130
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              },
              {
                "glbPosition": {
                  "x": 96,
                  "y": 142
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "variant": "default",
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 96,
                  "y": 142
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 72,
                "y": 142
              },
              "relPosition": {
                "x": 0,
                "y": 12
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target",
              "style": {
                "left": -3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 96,
                "y": 142
              },
              "relPosition": {
                "x": 24,
                "y": 12
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source",
              "style": {
                "right": -3
              }
            },
            "numericId": "5386926",
            "variable": {
              "id": "",
              "name": "lamp",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 24,
          "height": 24,
          "measured": {
            "width": 24,
            "height": 24
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_CLOSE_0b1455e3-6a1e-4fa1-aae2-4ed4acc626ef",
          "type": "parallel",
          "position": {
            "x": 141,
            "y": 49
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 141,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 141,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 145,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 141,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 145,
                "y": 50
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "1632009",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 145,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "input-down",
              "position": "bottom",
              "type": "target",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 145,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "output-top",
              "position": "top",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOpenReference": "PARALLEL_OPEN_526aa7e5-b3ad-4e57-a0ea-1900531f9022",
            "type": "close",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "CONTACT_9e6a810e-a598-43ff-961f-7376831966d8",
          "type": "contact",
          "position": {
            "x": 190,
            "y": 38
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 190,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              },
              {
                "glbPosition": {
                  "x": 214,
                  "y": 50
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "variant": "negated",
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 190,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 214,
                  "y": 50
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 190,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 12
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target",
              "style": {
                "left": -3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 214,
                "y": 50
              },
              "relPosition": {
                "x": 24,
                "y": 12
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source",
              "style": {
                "right": -3
              }
            },
            "numericId": "4764538",
            "variable": {
              "id": "",
              "name": "btn_2",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 24,
          "height": 24,
          "measured": {
            "width": 24,
            "height": 24
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "COIL_1dddd71d-606a-4e88-9d49-dcd2ddb7822c",
          "type": "coil",
          "position": {
            "x": 304,
            "y": 38
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 304,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              },
              {
                "glbPosition": {
                  "x": 332,
                  "y": 50
                },
                "relPosition": {
                  "x": 28,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "variant": "default",
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 304,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 332,
                  "y": 50
                },
                "relPosition": {
                  "x": 28,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 304,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 12
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target",
              "style": {
                "left": -3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 332,
                "y": 50
              },
              "relPosition": {
                "x": 28,
                "y": 12
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source",
              "style": {
                "right": -3
              }
            },
            "numericId": "2364037",
            "variable": {
              "id": "bbb68349-c768-48df-89fa-61da6357ebfc",
              "name": "lamp",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 28,
          "height": 24,
          "measured": {
            "width": 28,
            "height": 24
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "right-rail-rung_main_2776776c-b03b-4df7-aac0-6348c86dbffd",
          "type": "powerRail",
          "position": {
            "x": 442,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                },
                "x": 442
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                }
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 297,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "right-rail",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 20,
                "left": -3
              }
            },
            "numericId": "9405414",
            "variant": "right",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        }
      ],
      "edges": [
        {
          "id": "e_CONTACT_9e6a810e-a598-43ff-961f-7376831966d8_COIL_1dddd71d-606a-4e88-9d49-dcd2ddb7822c__output_input",
          "source": "CONTACT_9e6a810e-a598-43ff-961f-7376831966d8",
          "target": "COIL_1dddd71d-606a-4e88-9d49-dcd2ddb7822c",
          "sourceHandle": "output",
          "targetHandle": "input"
        },
        {
          "id": "e_COIL_1dddd71d-606a-4e88-9d49-dcd2ddb7822c_right-rail-rung_main_2776776c-b03b-4df7-aac0-6348c86dbffd__output_right-rail",
          "source": "COIL_1dddd71d-606a-4e88-9d49-dcd2ddb7822c",
          "target": "right-rail-rung_main_2776776c-b03b-4df7-aac0-6348c86dbffd",
          "sourceHandle": "output",
          "targetHandle": "right-rail"
        },
        {
          "id": "e_left-rail-rung_main_2776776c-b03b-4df7-aac0-6348c86dbffd_PARALLEL_OPEN_526aa7e5-b3ad-4e57-a0ea-1900531f9022__left-rail_input",
          "source": "left-rail-rung_main_2776776c-b03b-4df7-aac0-6348c86dbffd",
          "target": "PARALLEL_OPEN_526aa7e5-b3ad-4e57-a0ea-1900531f9022",
          "sourceHandle": "left-rail",
          "targetHandle": "input"
        },
        {
          "id": "e_PARALLEL_OPEN_526aa7e5-b3ad-4e57-a0ea-1900531f9022_CONTACT_724a8c06-e80c-4edc-90b0-3f2f640be7e2__output-right_input",
          "source": "PARALLEL_OPEN_526aa7e5-b3ad-4e57-a0ea-1900531f9022",
          "target": "CONTACT_724a8c06-e80c-4edc-90b0-3f2f640be7e2",
          "sourceHandle": "output-right",
          "targetHandle": "input"
        },
        {
          "id": "e_CONTACT_724a8c06-e80c-4edc-90b0-3f2f640be7e2_PARALLEL_CLOSE_0b1455e3-6a1e-4fa1-aae2-4ed4acc626ef__output_input",
          "source": "CONTACT_724a8c06-e80c-4edc-90b0-3f2f640be7e2",
          "target": "PARALLEL_CLOSE_0b1455e3-6a1e-4fa1-aae2-4ed4acc626ef",
          "sourceHandle": "output",
          "targetHandle": "input"
        },
        {
          "id": "e_PARALLEL_OPEN_526aa7e5-b3ad-4e57-a0ea-1900531f9022_CONTACT_25607947-3349-4b9d-aad9-489b9b00d578__output-down_input",
          "source": "PARALLEL_OPEN_526aa7e5-b3ad-4e57-a0ea-1900531f9022",
          "target": "CONTACT_25607947-3349-4b9d-aad9-489b9b00d578",
          "sourceHandle": "output-down",
          "targetHandle": "input"
        },
        {
          "id": "e_CONTACT_25607947-3349-4b9d-aad9-489b9b00d578_PARALLEL_CLOSE_0b1455e3-6a1e-4fa1-aae2-4ed4acc626ef__output_input-down",
          "source": "CONTACT_25607947-3349-4b9d-aad9-489b9b00d578",
          "target": "PARALLEL_CLOSE_0b1455e3-6a1e-4fa1-aae2-4ed4acc626ef",
          "sourceHandle": "output",
          "targetHandle": "input-down"
        },
        {
          "id": "e_PARALLEL_CLOSE_0b1455e3-6a1e-4fa1-aae2-4ed4acc626ef_CONTACT_9e6a810e-a598-43ff-961f-7376831966d8__output-right_input",
          "source": "PARALLEL_CLOSE_0b1455e3-6a1e-4fa1-aae2-4ed4acc626ef",
          "target": "CONTACT_9e6a810e-a598-43ff-961f-7376831966d8",
          "sourceHandle": "output-right",
          "targetHandle": "input"
        }
      ],
      "selectedNodes": [],
      "handleBranches": []
    },
    {
      "id": "rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2",
      "comment": "ゲームパッド信号",
      "defaultBounds": [
        300,
        100
      ],
      "reactFlowViewport": [
        706,
        694
      ],
      "nodes": [
        {
          "id": "left-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2",
          "type": "powerRail",
          "position": {
            "x": 0,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 3,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "left-rail",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 20,
                "right": -3
              }
            },
            "numericId": "7982010",
            "variant": "left",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "CONTACT_b1dd34a2-c0ea-40f7-adaf-221dc3bf8ca1",
          "type": "contact",
          "position": {
            "x": 68,
            "y": 38
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 68,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              },
              {
                "glbPosition": {
                  "x": 92,
                  "y": 50
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "variant": "risingEdge",
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 68,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 92,
                  "y": 50
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 68,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 12
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target",
              "style": {
                "left": -3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 92,
                "y": 50
              },
              "relPosition": {
                "x": 24,
                "y": 12
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source",
              "style": {
                "right": -3
              }
            },
            "numericId": "3154235",
            "variable": {
              "name": "isBlink"
            },
            "executionOrder": 0,
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 24,
          "height": 24,
          "measured": {
            "width": 24,
            "height": 24
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "type": "block",
          "position": {
            "x": 257,
            "y": 14
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 257,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 50
                },
                "relPosition": {
                  "x": 186,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 90
                },
                "relPosition": {
                  "x": 186,
                  "y": 76
                },
                "id": "axis_lx",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 130
                },
                "relPosition": {
                  "x": 186,
                  "y": 116
                },
                "id": "axis_ly",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 170
                },
                "relPosition": {
                  "x": 186,
                  "y": 156
                },
                "id": "axis_rx",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 156,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 210
                },
                "relPosition": {
                  "x": 186,
                  "y": 196
                },
                "id": "axis_ry",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 196,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 250
                },
                "relPosition": {
                  "x": 186,
                  "y": 236
                },
                "id": "btn_cross",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 236,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 290
                },
                "relPosition": {
                  "x": 186,
                  "y": 276
                },
                "id": "btn_circle",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 276,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 330
                },
                "relPosition": {
                  "x": 186,
                  "y": 316
                },
                "id": "btn_square",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 316,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 370
                },
                "relPosition": {
                  "x": 186,
                  "y": 356
                },
                "id": "btn_triangle",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 356,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 410
                },
                "relPosition": {
                  "x": 186,
                  "y": 396
                },
                "id": "btn_l1",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 396,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 450
                },
                "relPosition": {
                  "x": 186,
                  "y": 436
                },
                "id": "btn_r1",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 436,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 490
                },
                "relPosition": {
                  "x": 186,
                  "y": 476
                },
                "id": "axis_l2",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 476,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 530
                },
                "relPosition": {
                  "x": 186,
                  "y": 516
                },
                "id": "axis_r2",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 516,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 570
                },
                "relPosition": {
                  "x": 186,
                  "y": 556
                },
                "id": "dpad_x",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 556,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 610
                },
                "relPosition": {
                  "x": 186,
                  "y": 596
                },
                "id": "dpad_y",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 596,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 650
                },
                "relPosition": {
                  "x": 186,
                  "y": 636
                },
                "id": "connected",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 636,
                  "right": 0
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 257,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 443,
                  "y": 50
                },
                "relPosition": {
                  "x": 186,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 90
                },
                "relPosition": {
                  "x": 186,
                  "y": 76
                },
                "id": "axis_lx",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 130
                },
                "relPosition": {
                  "x": 186,
                  "y": 116
                },
                "id": "axis_ly",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 170
                },
                "relPosition": {
                  "x": 186,
                  "y": 156
                },
                "id": "axis_rx",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 156,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 210
                },
                "relPosition": {
                  "x": 186,
                  "y": 196
                },
                "id": "axis_ry",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 196,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 250
                },
                "relPosition": {
                  "x": 186,
                  "y": 236
                },
                "id": "btn_cross",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 236,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 290
                },
                "relPosition": {
                  "x": 186,
                  "y": 276
                },
                "id": "btn_circle",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 276,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 330
                },
                "relPosition": {
                  "x": 186,
                  "y": 316
                },
                "id": "btn_square",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 316,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 370
                },
                "relPosition": {
                  "x": 186,
                  "y": 356
                },
                "id": "btn_triangle",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 356,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 410
                },
                "relPosition": {
                  "x": 186,
                  "y": 396
                },
                "id": "btn_l1",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 396,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 450
                },
                "relPosition": {
                  "x": 186,
                  "y": 436
                },
                "id": "btn_r1",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 436,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 490
                },
                "relPosition": {
                  "x": 186,
                  "y": 476
                },
                "id": "axis_l2",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 476,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 530
                },
                "relPosition": {
                  "x": 186,
                  "y": 516
                },
                "id": "axis_r2",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 516,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 570
                },
                "relPosition": {
                  "x": 186,
                  "y": 556
                },
                "id": "dpad_x",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 556,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 610
                },
                "relPosition": {
                  "x": 186,
                  "y": 596
                },
                "id": "dpad_y",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 596,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 443,
                  "y": 650
                },
                "relPosition": {
                  "x": 186,
                  "y": 636
                },
                "id": "connected",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 636,
                  "right": 0
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 257,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 36
              },
              "id": "EN",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 36,
                "left": 0
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 443,
                "y": 50
              },
              "relPosition": {
                "x": 186,
                "y": 36
              },
              "id": "ENO",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 36,
                "right": 0
              }
            },
            "numericId": "6043949",
            "variant": {
              "name": "FB_GetGamepad",
              "documentation": "",
              "type": "function-block",
              "variables": [
                {
                  "name": "EN",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "ENO",
                  "class": "output",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "axis_lx",
                  "class": "output",
                  "type": {
                    "value": "REAL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "0.0",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "axis_ly",
                  "class": "output",
                  "type": {
                    "value": "REAL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "0.0",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "axis_rx",
                  "class": "output",
                  "type": {
                    "value": "REAL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "0.0",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "axis_ry",
                  "class": "output",
                  "type": {
                    "value": "REAL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "0.0",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "btn_cross",
                  "class": "output",
                  "type": {
                    "value": "BOOL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "FALSE",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "btn_circle",
                  "class": "output",
                  "type": {
                    "value": "BOOL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "FALSE",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "btn_square",
                  "class": "output",
                  "type": {
                    "value": "BOOL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "FALSE",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "btn_triangle",
                  "class": "output",
                  "type": {
                    "value": "BOOL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "FALSE",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "btn_l1",
                  "class": "output",
                  "type": {
                    "value": "BOOL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "FALSE",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "btn_r1",
                  "class": "output",
                  "type": {
                    "value": "BOOL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "FALSE",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "axis_l2",
                  "class": "output",
                  "type": {
                    "value": "REAL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "0.0",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "axis_r2",
                  "class": "output",
                  "type": {
                    "value": "REAL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "0.0",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "dpad_x",
                  "class": "output",
                  "type": {
                    "value": "SINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "0",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "dpad_y",
                  "class": "output",
                  "type": {
                    "value": "SINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "0",
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "connected",
                  "class": "output",
                  "type": {
                    "value": "BOOL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "FALSE",
                  "documentation": "",
                  "debug": false
                }
              ]
            },
            "variable": {
              "name": "instFB_GetGamepad",
              "class": "local",
              "type": {
                "definition": "derived",
                "value": "FB_GetGamepad"
              },
              "location": "",
              "initialValue": null,
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "executionControl": true,
            "lockExecutionControl": true,
            "connectedVariables": [],
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 186,
          "height": 660,
          "measured": {
            "width": 186,
            "height": 660
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "right-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2",
          "type": "powerRail",
          "position": {
            "x": 703,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                },
                "x": 703
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                }
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 297,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "right-rail",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 20,
                "left": -3
              }
            },
            "numericId": "10161429",
            "variant": "right",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_6b18a0b2-66dd-4dc5-aa35-4bd6f1be9183",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 90
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "10469206",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "axis_lx",
              "variableType": {
                "name": "axis_lx",
                "class": "output",
                "type": {
                  "value": "REAL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "0.0",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_270f7e36-9ac5-4bef-969f-86e85f28091f",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 114
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 130
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 130
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 130
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "724854",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "axis_ly",
              "variableType": {
                "name": "axis_ly",
                "class": "output",
                "type": {
                  "value": "REAL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "0.0",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_8e242b79-5e15-47a4-9648-91463aa0c935",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 154
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 170
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 170
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 170
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "8429468",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "axis_rx",
              "variableType": {
                "name": "axis_rx",
                "class": "output",
                "type": {
                  "value": "REAL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "0.0",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_d5afd7dc-a9c9-411f-9e28-023e60aca276",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 194
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 210
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 210
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 210
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "2620338",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "axis_ry",
              "variableType": {
                "name": "axis_ry",
                "class": "output",
                "type": {
                  "value": "REAL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "0.0",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_c6e28688-7cad-446c-b021-68fa4c72eeba",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 234
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 250
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 250
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 250
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "1951440",
            "variable": {
              "id": "2e430946-2a25-4476-99ec-5fbaad70527d",
              "name": "btn_1",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "btn_cross",
              "variableType": {
                "name": "btn_cross",
                "class": "output",
                "type": {
                  "value": "BOOL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "FALSE",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_ccdadffe-d77e-4530-b07f-6eaed31e23f3",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 274
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 290
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 290
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 290
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "9068383",
            "variable": {
              "id": "73524271-9604-4730-b7f4-62509a11b3da",
              "name": "btn_2",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "btn_circle",
              "variableType": {
                "name": "btn_circle",
                "class": "output",
                "type": {
                  "value": "BOOL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "FALSE",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_40ad8f5a-383b-4e5a-b661-ca28b78df199",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 314
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 330
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 330
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 330
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "4802417",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "btn_square",
              "variableType": {
                "name": "btn_square",
                "class": "output",
                "type": {
                  "value": "BOOL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "FALSE",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_f517e319-a0b9-45a2-9c75-8a4b627381e8",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 354
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 370
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 370
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 370
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "7018345",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "btn_triangle",
              "variableType": {
                "name": "btn_triangle",
                "class": "output",
                "type": {
                  "value": "BOOL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "FALSE",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_60dd7e52-4f83-47c3-a97d-0d10875edc73",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 394
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 410
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 410
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 410
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "4110880",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "btn_l1",
              "variableType": {
                "name": "btn_l1",
                "class": "output",
                "type": {
                  "value": "BOOL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "FALSE",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_aaa68dd4-9f9a-4ea6-ad17-429e320dce98",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 434
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 450
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 450
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 450
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "4578961",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "btn_r1",
              "variableType": {
                "name": "btn_r1",
                "class": "output",
                "type": {
                  "value": "BOOL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "FALSE",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_70f35dd8-4c5f-4553-b007-51993cb88fa4",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 474
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 490
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 490
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 490
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "7260096",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "axis_l2",
              "variableType": {
                "name": "axis_l2",
                "class": "output",
                "type": {
                  "value": "REAL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "0.0",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_d6a42783-46b6-4798-9ac3-00e97ed3377b",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 514
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 530
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 530
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 530
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "4115754",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "axis_r2",
              "variableType": {
                "name": "axis_r2",
                "class": "output",
                "type": {
                  "value": "REAL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "0.0",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_dc4daf2c-7bfc-4b2e-b6c9-b9756e333cf1",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 554
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 570
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 570
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 570
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "5182379",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "dpad_x",
              "variableType": {
                "name": "dpad_x",
                "class": "output",
                "type": {
                  "value": "SINT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "0",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_adf4b02b-9eb2-4a4c-bec7-c5211c3bf543",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 594
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 610
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 610
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 610
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "7173273",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "dpad_y",
              "variableType": {
                "name": "dpad_y",
                "class": "output",
                "type": {
                  "value": "SINT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "0",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_eb23839b-8129-45c3-849c-3a222566b873",
          "type": "variable",
          "position": {
            "x": 473,
            "y": 634
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 650
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 473,
                  "y": 650
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 473,
                "y": 650
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "1921747",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
              "handleId": "connected",
              "variableType": {
                "name": "connected",
                "class": "output",
                "type": {
                  "value": "BOOL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": "FALSE",
                "documentation": "",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        }
      ],
      "edges": [
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_right-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2__???_right-rail",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "right-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2",
          "sourceHandle": "ENO",
          "targetHandle": "right-rail"
        },
        {
          "id": "e_left-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2_CONTACT_b1dd34a2-c0ea-40f7-adaf-221dc3bf8ca1__left-rail_input",
          "source": "left-rail-rung_main_f7f5c5a9-d24e-48a0-94c0-e212f2e772a2",
          "target": "CONTACT_b1dd34a2-c0ea-40f7-adaf-221dc3bf8ca1",
          "sourceHandle": "left-rail",
          "targetHandle": "input"
        },
        {
          "id": "e_CONTACT_b1dd34a2-c0ea-40f7-adaf-221dc3bf8ca1_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3__output_EN",
          "source": "CONTACT_b1dd34a2-c0ea-40f7-adaf-221dc3bf8ca1",
          "target": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "sourceHandle": "output",
          "targetHandle": "EN"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_6b18a0b2-66dd-4dc5-aa35-4bd6f1be9183__axis_lx_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_6b18a0b2-66dd-4dc5-aa35-4bd6f1be9183",
          "sourceHandle": "axis_lx",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_270f7e36-9ac5-4bef-969f-86e85f28091f__axis_ly_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_270f7e36-9ac5-4bef-969f-86e85f28091f",
          "sourceHandle": "axis_ly",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_8e242b79-5e15-47a4-9648-91463aa0c935__axis_rx_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_8e242b79-5e15-47a4-9648-91463aa0c935",
          "sourceHandle": "axis_rx",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_d5afd7dc-a9c9-411f-9e28-023e60aca276__axis_ry_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_d5afd7dc-a9c9-411f-9e28-023e60aca276",
          "sourceHandle": "axis_ry",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_c6e28688-7cad-446c-b021-68fa4c72eeba__btn_cross_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_c6e28688-7cad-446c-b021-68fa4c72eeba",
          "sourceHandle": "btn_cross",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_ccdadffe-d77e-4530-b07f-6eaed31e23f3__btn_circle_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_ccdadffe-d77e-4530-b07f-6eaed31e23f3",
          "sourceHandle": "btn_circle",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_40ad8f5a-383b-4e5a-b661-ca28b78df199__btn_square_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_40ad8f5a-383b-4e5a-b661-ca28b78df199",
          "sourceHandle": "btn_square",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_f517e319-a0b9-45a2-9c75-8a4b627381e8__btn_triangle_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_f517e319-a0b9-45a2-9c75-8a4b627381e8",
          "sourceHandle": "btn_triangle",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_60dd7e52-4f83-47c3-a97d-0d10875edc73__btn_l1_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_60dd7e52-4f83-47c3-a97d-0d10875edc73",
          "sourceHandle": "btn_l1",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_aaa68dd4-9f9a-4ea6-ad17-429e320dce98__btn_r1_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_aaa68dd4-9f9a-4ea6-ad17-429e320dce98",
          "sourceHandle": "btn_r1",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_70f35dd8-4c5f-4553-b007-51993cb88fa4__axis_l2_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_70f35dd8-4c5f-4553-b007-51993cb88fa4",
          "sourceHandle": "axis_l2",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_d6a42783-46b6-4798-9ac3-00e97ed3377b__axis_r2_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_d6a42783-46b6-4798-9ac3-00e97ed3377b",
          "sourceHandle": "axis_r2",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_dc4daf2c-7bfc-4b2e-b6c9-b9756e333cf1__dpad_x_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_dc4daf2c-7bfc-4b2e-b6c9-b9756e333cf1",
          "sourceHandle": "dpad_x",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_adf4b02b-9eb2-4a4c-bec7-c5211c3bf543__dpad_y_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_adf4b02b-9eb2-4a4c-bec7-c5211c3bf543",
          "sourceHandle": "dpad_y",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3_VARIABLE_eb23839b-8129-45c3-849c-3a222566b873__connected_input",
          "source": "BLOCK_079ce87f-ee15-4f97-aa72-add19ca30cc3",
          "target": "VARIABLE_eb23839b-8129-45c3-849c-3a222566b873",
          "sourceHandle": "connected",
          "targetHandle": "input"
        }
      ],
      "selectedNodes": [],
      "handleBranches": []
    },
    {
      "id": "rung_main_fec0734c-42b6-4285-be65-55f4e8049f30",
      "comment": "時刻取得",
      "defaultBounds": [
        300,
        100
      ],
      "reactFlowViewport": [
        1604,
        454
      ],
      "selectedNodes": [],
      "nodes": [
        {
          "id": "left-rail-rung_main_0f89c824-463a-4dcf-8a45-0abaac15d086",
          "type": "powerRail",
          "position": {
            "x": 0,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 3,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "left-rail",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 20,
                "right": -3
              }
            },
            "numericId": "7720416",
            "variant": "left",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "BLOCK_29b3706c-09b2-4bc6-8228-fb615803693d",
          "type": "block",
          "position": {
            "x": 143,
            "y": 14
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 143,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 263,
                  "y": 50
                },
                "relPosition": {
                  "x": 120,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 263,
                  "y": 90
                },
                "relPosition": {
                  "x": 120,
                  "y": 76
                },
                "id": "OUT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 143,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 263,
                  "y": 50
                },
                "relPosition": {
                  "x": 120,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 263,
                  "y": 90
                },
                "relPosition": {
                  "x": 120,
                  "y": 76
                },
                "id": "OUT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 143,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 36
              },
              "id": "EN",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 36,
                "left": 0
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 263,
                "y": 50
              },
              "relPosition": {
                "x": 120,
                "y": 36
              },
              "id": "ENO",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 36,
                "right": 0
              }
            },
            "numericId": "2032477",
            "variant": {
              "name": "CURRENT_DT",
              "type": "function",
              "language": "st",
              "variables": [
                {
                  "name": "EN",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "ENO",
                  "class": "output",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "OUT",
                  "class": "output",
                  "type": {
                    "definition": "base-type",
                    "value": "DT"
                  }
                }
              ],
              "body": "",
              "documentation": "",
              "extensible": false,
              "category": "Time"
            },
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "executionControl": true,
            "lockExecutionControl": true,
            "connectedVariables": [
              {
                "handleId": "OUT",
                "type": "output",
                "variable": {
                  "id": "ed5ef08a-9078-4136-bf8e-7f9486c42a93",
                  "name": "CurrentDT",
                  "type": {
                    "definition": "base-type",
                    "value": "DT"
                  },
                  "class": "local",
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              }
            ],
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 120,
          "height": 100,
          "measured": {
            "width": 120,
            "height": 100
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
          "type": "block",
          "position": {
            "x": 503,
            "y": 14
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 503,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 503,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "dtUTC",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 50
                },
                "relPosition": {
                  "x": 174,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 90
                },
                "relPosition": {
                  "x": 174,
                  "y": 76
                },
                "id": "iYear",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 130
                },
                "relPosition": {
                  "x": 174,
                  "y": 116
                },
                "id": "iMonth",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 170
                },
                "relPosition": {
                  "x": 174,
                  "y": 156
                },
                "id": "iDay",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 156,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 210
                },
                "relPosition": {
                  "x": 174,
                  "y": 196
                },
                "id": "iHour",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 196,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 250
                },
                "relPosition": {
                  "x": 174,
                  "y": 236
                },
                "id": "iMinute",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 236,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 290
                },
                "relPosition": {
                  "x": 174,
                  "y": 276
                },
                "id": "iSecond",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 276,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 330
                },
                "relPosition": {
                  "x": 174,
                  "y": 316
                },
                "id": "iWeekday",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 316,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 370
                },
                "relPosition": {
                  "x": 174,
                  "y": 356
                },
                "id": "xValid",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 356,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 410
                },
                "relPosition": {
                  "x": 174,
                  "y": 396
                },
                "id": "lRawDT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 396,
                  "right": 0
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 503,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 503,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "dtUTC",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 677,
                  "y": 50
                },
                "relPosition": {
                  "x": 174,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 90
                },
                "relPosition": {
                  "x": 174,
                  "y": 76
                },
                "id": "iYear",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 130
                },
                "relPosition": {
                  "x": 174,
                  "y": 116
                },
                "id": "iMonth",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 170
                },
                "relPosition": {
                  "x": 174,
                  "y": 156
                },
                "id": "iDay",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 156,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 210
                },
                "relPosition": {
                  "x": 174,
                  "y": 196
                },
                "id": "iHour",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 196,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 250
                },
                "relPosition": {
                  "x": 174,
                  "y": 236
                },
                "id": "iMinute",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 236,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 290
                },
                "relPosition": {
                  "x": 174,
                  "y": 276
                },
                "id": "iSecond",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 276,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 330
                },
                "relPosition": {
                  "x": 174,
                  "y": 316
                },
                "id": "iWeekday",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 316,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 370
                },
                "relPosition": {
                  "x": 174,
                  "y": 356
                },
                "id": "xValid",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 356,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 677,
                  "y": 410
                },
                "relPosition": {
                  "x": 174,
                  "y": 396
                },
                "id": "lRawDT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 396,
                  "right": 0
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 503,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 36
              },
              "id": "EN",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 36,
                "left": 0
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 677,
                "y": 50
              },
              "relPosition": {
                "x": 174,
                "y": 36
              },
              "id": "ENO",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 36,
                "right": 0
              }
            },
            "numericId": "6759093",
            "variant": {
              "name": "FB_UtcToJst",
              "documentation": "",
              "type": "function-block",
              "variables": [
                {
                  "name": "EN",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "ENO",
                  "class": "output",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "dtUTC",
                  "class": "input",
                  "type": {
                    "value": "DT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "現在時刻 (UTC)",
                  "debug": false
                },
                {
                  "name": "iYear",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "年 (例: 2026)",
                  "debug": false
                },
                {
                  "name": "iMonth",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "月 1-12",
                  "debug": false
                },
                {
                  "name": "iDay",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "日 1-31",
                  "debug": false
                },
                {
                  "name": "iHour",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "時 0-23",
                  "debug": false
                },
                {
                  "name": "iMinute",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "分 0-59",
                  "debug": false
                },
                {
                  "name": "iSecond",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "秒 0-59",
                  "debug": false
                },
                {
                  "name": "iWeekday",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "曜日 0=日 ... 6=土",
                  "debug": false
                },
                {
                  "name": "xValid",
                  "class": "output",
                  "type": {
                    "value": "BOOL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "変換結果が有効 (1970年より前の時刻なら FALSE)",
                  "debug": false
                },
                {
                  "name": "lRawDT",
                  "class": "output",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "確認用: DT_TO_LINT の生の値",
                  "debug": false
                },
                {
                  "name": "JST_OFFSET_S",
                  "class": "local",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": "32400",
                  "documentation": "9時間 [秒]",
                  "debug": false,
                  "flag": "constant"
                },
                {
                  "name": "lSec",
                  "class": "local",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "JST の経過秒",
                  "debug": false
                },
                {
                  "name": "lDays",
                  "class": "local",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "JST の経過日数",
                  "debug": false
                },
                {
                  "name": "lSecOfDay",
                  "class": "local",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "その日の 0:00 からの秒",
                  "debug": false
                },
                {
                  "name": "z",
                  "class": "local",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "era",
                  "class": "local",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "doe",
                  "class": "local",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "yoe",
                  "class": "local",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "doy",
                  "class": "local",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "mp",
                  "class": "local",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "y",
                  "class": "local",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "m",
                  "class": "local",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "",
                  "debug": false
                },
                {
                  "name": "d",
                  "class": "local",
                  "type": {
                    "value": "LINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "",
                  "debug": false
                }
              ]
            },
            "variable": {
              "name": "instUtcToJst",
              "class": "local",
              "type": {
                "definition": "derived",
                "value": "FB_UtcToJst"
              },
              "location": "",
              "initialValue": null,
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "executionControl": true,
            "lockExecutionControl": true,
            "connectedVariables": [
              {
                "handleId": "dtUTC",
                "type": "input",
                "variable": {
                  "name": "CurrentDT",
                  "class": "local",
                  "type": {
                    "definition": "base-type",
                    "value": "DT"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "iYear",
                "type": "output",
                "variable": {
                  "name": "gYear",
                  "class": "external",
                  "type": {
                    "definition": "base-type",
                    "value": "INT"
                  },
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "iDay",
                "type": "output",
                "variable": {
                  "name": "gDay",
                  "class": "external",
                  "type": {
                    "definition": "base-type",
                    "value": "INT"
                  },
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "iHour",
                "type": "output",
                "variable": {
                  "name": "gHour",
                  "class": "external",
                  "type": {
                    "definition": "base-type",
                    "value": "INT"
                  },
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "iMinute",
                "type": "output",
                "variable": {
                  "name": "gMinute",
                  "class": "external",
                  "type": {
                    "definition": "base-type",
                    "value": "INT"
                  },
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "iWeekday",
                "type": "output",
                "variable": {
                  "name": "gWeek",
                  "class": "external",
                  "type": {
                    "definition": "base-type",
                    "value": "INT"
                  },
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "iMonth",
                "type": "output",
                "variable": {
                  "name": "gMonth",
                  "class": "external",
                  "type": {
                    "definition": "base-type",
                    "value": "INT"
                  },
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "iSecond",
                "type": "output",
                "variable": {
                  "id": "",
                  "name": "sec",
                  "type": {
                    "definition": "base-type",
                    "value": "INT"
                  },
                  "class": "local",
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              }
            ],
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 174,
          "height": 420,
          "measured": {
            "width": 174,
            "height": 420
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_OPEN_4234044b-331e-44f5-9431-81132dd96497",
          "type": "parallel",
          "position": {
            "x": 797,
            "y": 49
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 797,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 801,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              },
              {
                "glbPosition": {
                  "x": 801,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 801,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 797,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 801,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 801,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 801,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 797,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 801,
                "y": 50
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "7578003",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 801,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "input-top",
              "position": "top",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 801,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "output-down",
              "position": "bottom",
              "type": "source",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelCloseReference": "PARALLEL_CLOSE_47e34ee6-475f-4a92-b866-d6766f7f8982",
            "type": "open",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "BLOCK_78683974-0032-49b0-8f27-3f607e25909e",
          "type": "block",
          "position": {
            "x": 921,
            "y": 14
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 921,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 921,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "IN1",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 921,
                  "y": 130
                },
                "relPosition": {
                  "x": 0,
                  "y": 116
                },
                "id": "IN2",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 1011,
                  "y": 50
                },
                "relPosition": {
                  "x": 90,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 1011,
                  "y": 90
                },
                "relPosition": {
                  "x": 90,
                  "y": 76
                },
                "id": "OUT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 921,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 921,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "IN1",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 921,
                  "y": 130
                },
                "relPosition": {
                  "x": 0,
                  "y": 116
                },
                "id": "IN2",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "left": 0
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 1011,
                  "y": 50
                },
                "relPosition": {
                  "x": 90,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 1011,
                  "y": 90
                },
                "relPosition": {
                  "x": 90,
                  "y": 76
                },
                "id": "OUT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 921,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 36
              },
              "id": "EN",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 36,
                "left": 0
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 1011,
                "y": 50
              },
              "relPosition": {
                "x": 90,
                "y": 36
              },
              "id": "ENO",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 36,
                "right": 0
              }
            },
            "numericId": "801519",
            "variant": {
              "name": "EQ",
              "type": "function",
              "variables": [
                {
                  "name": "EN",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "ENO",
                  "class": "output",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "OUT",
                  "class": "output",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "IN1",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "ANY_ELEMENTARY"
                  }
                },
                {
                  "name": "IN2",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "ANY_ELEMENTARY"
                  }
                }
              ],
              "documentation": "",
              "extensible": true
            },
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "executionControl": true,
            "lockExecutionControl": false,
            "connectedVariables": [
              {
                "handleId": "OUT",
                "type": "output",
                "variable": {
                  "id": "0bf61f00-1ee5-4ff5-9622-b6377d81ad66",
                  "name": "getFlag",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  },
                  "class": "local",
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "IN2",
                "type": "input",
                "variable": {
                  "name": "0"
                }
              },
              {
                "handleId": "IN1",
                "type": "input",
                "variable": {
                  "name": "gMinute",
                  "class": "external",
                  "type": {
                    "definition": "base-type",
                    "value": "INT"
                  },
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              }
            ],
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 90,
          "height": 140,
          "measured": {
            "width": 90,
            "height": 140
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238",
          "type": "block",
          "position": {
            "x": 921,
            "y": 198
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 921,
                  "y": 234
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 921,
                  "y": 274
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "IN1",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 921,
                  "y": 314
                },
                "relPosition": {
                  "x": 0,
                  "y": 116
                },
                "id": "IN2",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 1011,
                  "y": 234
                },
                "relPosition": {
                  "x": 90,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 1011,
                  "y": 274
                },
                "relPosition": {
                  "x": 90,
                  "y": 76
                },
                "id": "OUT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 921,
                  "y": 234
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 921,
                  "y": 274
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "IN1",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 921,
                  "y": 314
                },
                "relPosition": {
                  "x": 0,
                  "y": 116
                },
                "id": "IN2",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "left": 0
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 1011,
                  "y": 234
                },
                "relPosition": {
                  "x": 90,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 1011,
                  "y": 274
                },
                "relPosition": {
                  "x": 90,
                  "y": 76
                },
                "id": "OUT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 921,
                "y": 234
              },
              "relPosition": {
                "x": 0,
                "y": 36
              },
              "id": "EN",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 36,
                "left": 0
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 1011,
                "y": 234
              },
              "relPosition": {
                "x": 90,
                "y": 36
              },
              "id": "ENO",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 36,
                "right": 0
              }
            },
            "numericId": "6684188",
            "variant": {
              "name": "MOD",
              "type": "function",
              "language": "st",
              "variables": [
                {
                  "name": "EN",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "ENO",
                  "class": "output",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "OUT",
                  "class": "output",
                  "type": {
                    "definition": "generic-type",
                    "value": "ANY_NUM"
                  }
                },
                {
                  "name": "IN1",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "ANY_NUM"
                  }
                },
                {
                  "name": "IN2",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "ANY_NUM"
                  }
                }
              ],
              "body": "",
              "documentation": "",
              "extensible": false,
              "category": "Arithmetic"
            },
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "executionControl": true,
            "lockExecutionControl": true,
            "connectedVariables": [
              {
                "handleId": "OUT",
                "type": "output",
                "variable": {
                  "id": "395b77d5-4195-4f3e-a337-611e8bb8e8b8",
                  "name": "sec10",
                  "type": {
                    "definition": "base-type",
                    "value": "INT"
                  },
                  "class": "local",
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "IN1",
                "type": "input",
                "variable": {
                  "id": "cbb7a57a-0aac-4d87-bfd9-c7aef2a630f9",
                  "name": "sec",
                  "type": {
                    "definition": "base-type",
                    "value": "INT"
                  },
                  "class": "local",
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "IN2",
                "type": "input",
                "variable": {
                  "name": "10"
                }
              }
            ],
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 90,
          "height": 140,
          "measured": {
            "width": 90,
            "height": 140
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60",
          "type": "block",
          "position": {
            "x": 1251,
            "y": 198
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 1251,
                  "y": 234
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 1251,
                  "y": 274
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "IN1",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 1251,
                  "y": 314
                },
                "relPosition": {
                  "x": 0,
                  "y": 116
                },
                "id": "IN2",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 1341,
                  "y": 234
                },
                "relPosition": {
                  "x": 90,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 1341,
                  "y": 274
                },
                "relPosition": {
                  "x": 90,
                  "y": 76
                },
                "id": "OUT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 1251,
                  "y": 234
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 1251,
                  "y": 274
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "IN1",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 1251,
                  "y": 314
                },
                "relPosition": {
                  "x": 0,
                  "y": 116
                },
                "id": "IN2",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "left": 0
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 1341,
                  "y": 234
                },
                "relPosition": {
                  "x": 90,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 1341,
                  "y": 274
                },
                "relPosition": {
                  "x": 90,
                  "y": 76
                },
                "id": "OUT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 1251,
                "y": 234
              },
              "relPosition": {
                "x": 0,
                "y": 36
              },
              "id": "EN",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 36,
                "left": 0
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 1341,
                "y": 234
              },
              "relPosition": {
                "x": 90,
                "y": 36
              },
              "id": "ENO",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 36,
                "right": 0
              }
            },
            "numericId": "7961360",
            "variant": {
              "name": "GE",
              "type": "function",
              "language": "st",
              "variables": [
                {
                  "name": "EN",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "ENO",
                  "class": "output",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "OUT",
                  "class": "output",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "IN1",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "ANY_ELEMENTARY"
                  }
                },
                {
                  "name": "IN2",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "ANY_ELEMENTARY"
                  }
                }
              ],
              "body": "",
              "documentation": "",
              "extensible": true,
              "category": "Comparison"
            },
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "executionControl": true,
            "lockExecutionControl": false,
            "connectedVariables": [
              {
                "handleId": "IN1",
                "type": "input",
                "variable": {
                  "id": "395b77d5-4195-4f3e-a337-611e8bb8e8b8",
                  "name": "sec10",
                  "type": {
                    "definition": "base-type",
                    "value": "INT"
                  },
                  "class": "local",
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "IN2",
                "type": "input",
                "variable": {
                  "name": "5"
                }
              },
              {
                "handleId": "OUT",
                "type": "output",
                "variable": {
                  "name": "gFlicker",
                  "class": "external",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  },
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              }
            ],
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 90,
          "height": 140,
          "measured": {
            "width": 90,
            "height": 140
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_CLOSE_47e34ee6-475f-4a92-b866-d6766f7f8982",
          "type": "parallel",
          "position": {
            "x": 1461,
            "y": 49
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 1461,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 1465,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              },
              {
                "glbPosition": {
                  "x": 1465,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 1465,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 1461,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 1465,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 1465,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 1465,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 1461,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 1465,
                "y": 50
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "9277772",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 1465,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "input-down",
              "position": "bottom",
              "type": "target",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 1465,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "output-top",
              "position": "top",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOpenReference": "PARALLEL_OPEN_4234044b-331e-44f5-9431-81132dd96497",
            "type": "close",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "right-rail-rung_main_0f89c824-463a-4dcf-8a45-0abaac15d086",
          "type": "powerRail",
          "position": {
            "x": 1601,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                },
                "x": 1601
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                },
                "x": 847
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 297,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "right-rail",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 20,
                "left": -3
              }
            },
            "numericId": "6583283",
            "variant": "right",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_1b7c3f3e-010b-438c-90e4-6881548094f2",
          "type": "variable",
          "position": {
            "x": 293,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 293,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 293,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 293,
                "y": 90
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "6472387",
            "variable": {
              "id": "ed5ef08a-9078-4136-bf8e-7f9486c42a93",
              "name": "CurrentDT",
              "type": {
                "definition": "base-type",
                "value": "DT"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_29b3706c-09b2-4bc6-8228-fb615803693d",
              "handleId": "OUT",
              "variableType": {
                "name": "OUT",
                "class": "output",
                "type": {
                  "definition": "base-type",
                  "value": "DT"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_fbea204f-b6b1-4093-a39d-572f9c6ef496",
          "type": "variable",
          "position": {
            "x": 393,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 553,
                  "y": 90
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 553,
                  "y": 90
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 553,
                "y": 90
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "1773762",
            "variable": {
              "name": "CurrentDT",
              "class": "local",
              "type": {
                "definition": "base-type",
                "value": "DT"
              },
              "location": "",
              "initialValue": null,
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
              "handleId": "dtUTC",
              "variableType": {
                "name": "dtUTC",
                "class": "input",
                "type": {
                  "value": "DT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "現在時刻 (UTC)",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_cb320d6a-8cba-4cac-b8ed-a73a54e45d0f",
          "type": "variable",
          "position": {
            "x": 707,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 707,
                "y": 90
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "6957327",
            "variable": {
              "name": "gYear",
              "class": "external",
              "type": {
                "definition": "base-type",
                "value": "INT"
              },
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
              "handleId": "iYear",
              "variableType": {
                "name": "iYear",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "年 (例: 2026)",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_e4a2cff7-7c40-40a4-8f6a-fe44fa53e120",
          "type": "variable",
          "position": {
            "x": 707,
            "y": 114
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 130
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 130
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 707,
                "y": 130
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "10503509",
            "variable": {
              "name": "gMonth",
              "class": "external",
              "type": {
                "definition": "base-type",
                "value": "INT"
              },
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
              "handleId": "iMonth",
              "variableType": {
                "name": "iMonth",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "月 1-12",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_119a264c-842d-4453-a6fa-12a2fbaacdfe",
          "type": "variable",
          "position": {
            "x": 707,
            "y": 154
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 170
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 170
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 707,
                "y": 170
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "4629159",
            "variable": {
              "name": "gDay",
              "class": "external",
              "type": {
                "definition": "base-type",
                "value": "INT"
              },
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
              "handleId": "iDay",
              "variableType": {
                "name": "iDay",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "日 1-31",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_77504960-34ad-4ce4-ac82-cbb889f99bf1",
          "type": "variable",
          "position": {
            "x": 707,
            "y": 194
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 210
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 210
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 707,
                "y": 210
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "8986599",
            "variable": {
              "name": "gHour",
              "class": "external",
              "type": {
                "definition": "base-type",
                "value": "INT"
              },
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
              "handleId": "iHour",
              "variableType": {
                "name": "iHour",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "時 0-23",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_f9324f59-0360-4ffa-a6f0-4ddd315e1ac8",
          "type": "variable",
          "position": {
            "x": 707,
            "y": 234
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 250
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 250
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 707,
                "y": 250
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "8466535",
            "variable": {
              "name": "gMinute",
              "class": "external",
              "type": {
                "definition": "base-type",
                "value": "INT"
              },
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
              "handleId": "iMinute",
              "variableType": {
                "name": "iMinute",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "分 0-59",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_f1e07cba-f942-419e-9f8b-e870317a00ce",
          "type": "variable",
          "position": {
            "x": 707,
            "y": 274
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 290
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 290
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 707,
                "y": 290
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "5380070",
            "variable": {
              "id": "",
              "name": "sec",
              "type": {
                "definition": "base-type",
                "value": "INT"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
              "handleId": "iSecond",
              "variableType": {
                "name": "iSecond",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "秒 0-59",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_9247cd9e-b4a4-414e-b93e-4d0beab1cd21",
          "type": "variable",
          "position": {
            "x": 707,
            "y": 314
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 330
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 330
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 707,
                "y": 330
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "6270507",
            "variable": {
              "name": "gWeek",
              "class": "external",
              "type": {
                "definition": "base-type",
                "value": "INT"
              },
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
              "handleId": "iWeekday",
              "variableType": {
                "name": "iWeekday",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "曜日 0=日 ... 6=土",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_0ae9c662-5bca-4677-8de2-3be63017c6a2",
          "type": "variable",
          "position": {
            "x": 707,
            "y": 354
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 370
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 370
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 707,
                "y": 370
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "10116873",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
              "handleId": "xValid",
              "variableType": {
                "name": "xValid",
                "class": "output",
                "type": {
                  "value": "BOOL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "変換結果が有効 (1970年より前の時刻なら FALSE)",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_f30a951a-3de7-47a8-8d6f-c50895031eb8",
          "type": "variable",
          "position": {
            "x": 707,
            "y": 394
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 410
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 707,
                  "y": 410
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 707,
                "y": 410
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "6309658",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
              "handleId": "lRawDT",
              "variableType": {
                "name": "lRawDT",
                "class": "output",
                "type": {
                  "value": "LINT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "確認用: DT_TO_LINT の生の値",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_83995c73-0bf3-48d5-8b06-e6afa7a2d267",
          "type": "variable",
          "position": {
            "x": 811,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 971,
                  "y": 90
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 971,
                  "y": 90
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 971,
                "y": 90
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "2866358",
            "variable": {
              "name": "gMinute",
              "class": "external",
              "type": {
                "definition": "base-type",
                "value": "INT"
              },
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_78683974-0032-49b0-8f27-3f607e25909e",
              "handleId": "IN1",
              "variableType": {
                "name": "IN1",
                "class": "input",
                "type": {
                  "definition": "generic-type",
                  "value": "ANY_ELEMENTARY"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_4f6eaeb2-c7e6-4168-bced-e4e514ba49c8",
          "type": "variable",
          "position": {
            "x": 811,
            "y": 114
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 971,
                  "y": 130
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 971,
                  "y": 130
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 971,
                "y": 130
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "5967527",
            "variable": {
              "name": "0"
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_78683974-0032-49b0-8f27-3f607e25909e",
              "handleId": "IN2",
              "variableType": {
                "name": "IN2",
                "class": "input",
                "type": {
                  "definition": "generic-type",
                  "value": "ANY_ELEMENTARY"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_e98e6388-efd8-4fcf-8323-1d21a78d7dae",
          "type": "variable",
          "position": {
            "x": 1041,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 1041,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 1041,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 1041,
                "y": 90
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "5654281",
            "variable": {
              "id": "0bf61f00-1ee5-4ff5-9622-b6377d81ad66",
              "name": "getFlag",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_78683974-0032-49b0-8f27-3f607e25909e",
              "handleId": "OUT",
              "variableType": {
                "name": "OUT",
                "class": "output",
                "type": {
                  "definition": "base-type",
                  "value": "BOOL"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_89ffaf83-c8db-466d-bc26-521ce34f9766",
          "type": "variable",
          "position": {
            "x": 811,
            "y": 258
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 971,
                  "y": 274
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 971,
                  "y": 274
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 971,
                "y": 274
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "10435878",
            "variable": {
              "id": "cbb7a57a-0aac-4d87-bfd9-c7aef2a630f9",
              "name": "sec",
              "type": {
                "definition": "base-type",
                "value": "INT"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238",
              "handleId": "IN1",
              "variableType": {
                "name": "IN1",
                "class": "input",
                "type": {
                  "definition": "generic-type",
                  "value": "ANY_NUM"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_b6ef30f3-e955-4a38-a4ec-c6da52420d94",
          "type": "variable",
          "position": {
            "x": 811,
            "y": 298
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 971,
                  "y": 314
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 971,
                  "y": 314
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 971,
                "y": 314
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "1700125",
            "variable": {
              "name": "10"
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238",
              "handleId": "IN2",
              "variableType": {
                "name": "IN2",
                "class": "input",
                "type": {
                  "definition": "generic-type",
                  "value": "ANY_NUM"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_52f5829c-dda1-4e4d-bd21-4ae74e8e847e",
          "type": "variable",
          "position": {
            "x": 1041,
            "y": 258
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 1041,
                  "y": 274
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 1041,
                  "y": 274
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 1041,
                "y": 274
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "5358513",
            "variable": {
              "id": "395b77d5-4195-4f3e-a337-611e8bb8e8b8",
              "name": "sec10",
              "type": {
                "definition": "base-type",
                "value": "INT"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238",
              "handleId": "OUT",
              "variableType": {
                "name": "OUT",
                "class": "output",
                "type": {
                  "definition": "generic-type",
                  "value": "ANY_NUM"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_8caeda20-6022-4a76-8f13-eff5bd97a5e7",
          "type": "variable",
          "position": {
            "x": 1141,
            "y": 258
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 1301,
                  "y": 274
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 1301,
                  "y": 274
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 1301,
                "y": 274
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "6829236",
            "variable": {
              "id": "395b77d5-4195-4f3e-a337-611e8bb8e8b8",
              "name": "sec10",
              "type": {
                "definition": "base-type",
                "value": "INT"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60",
              "handleId": "IN1",
              "variableType": {
                "name": "IN1",
                "class": "input",
                "type": {
                  "definition": "generic-type",
                  "value": "ANY_ELEMENTARY"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_6ed2e5bc-c7d4-46d0-9e21-c988fc7e31d8",
          "type": "variable",
          "position": {
            "x": 1141,
            "y": 298
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 1301,
                  "y": 314
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 1301,
                  "y": 314
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 1301,
                "y": 314
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "6310556",
            "variable": {
              "name": "5"
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60",
              "handleId": "IN2",
              "variableType": {
                "name": "IN2",
                "class": "input",
                "type": {
                  "definition": "generic-type",
                  "value": "ANY_ELEMENTARY"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_55c6d84f-85a2-440d-9b98-1a0a556211d5",
          "type": "variable",
          "position": {
            "x": 1371,
            "y": 258
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 1371,
                  "y": 274
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 1371,
                  "y": 274
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 1371,
                "y": 274
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "9996196",
            "variable": {
              "name": "gFlicker",
              "class": "external",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60",
              "handleId": "OUT",
              "variableType": {
                "name": "OUT",
                "class": "output",
                "type": {
                  "definition": "base-type",
                  "value": "BOOL"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        }
      ],
      "edges": [
        {
          "id": "e_BLOCK_29b3706c-09b2-4bc6-8228-fb615803693d_BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9__???_EN",
          "source": "BLOCK_29b3706c-09b2-4bc6-8228-fb615803693d",
          "target": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
          "sourceHandle": "ENO",
          "targetHandle": "EN"
        },
        {
          "id": "e_left-rail-rung_main_0f89c824-463a-4dcf-8a45-0abaac15d086_BLOCK_29b3706c-09b2-4bc6-8228-fb615803693d__left-rail_EN",
          "source": "left-rail-rung_main_0f89c824-463a-4dcf-8a45-0abaac15d086",
          "target": "BLOCK_29b3706c-09b2-4bc6-8228-fb615803693d",
          "sourceHandle": "left-rail",
          "targetHandle": "EN"
        },
        {
          "id": "e_BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9_PARALLEL_OPEN_4234044b-331e-44f5-9431-81132dd96497__ENO_input",
          "source": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
          "target": "PARALLEL_OPEN_4234044b-331e-44f5-9431-81132dd96497",
          "sourceHandle": "ENO",
          "targetHandle": "input"
        },
        {
          "id": "e_PARALLEL_OPEN_4234044b-331e-44f5-9431-81132dd96497_BLOCK_78683974-0032-49b0-8f27-3f607e25909e__output-right_EN",
          "source": "PARALLEL_OPEN_4234044b-331e-44f5-9431-81132dd96497",
          "target": "BLOCK_78683974-0032-49b0-8f27-3f607e25909e",
          "sourceHandle": "output-right",
          "targetHandle": "EN"
        },
        {
          "id": "e_BLOCK_78683974-0032-49b0-8f27-3f607e25909e_PARALLEL_CLOSE_47e34ee6-475f-4a92-b866-d6766f7f8982__ENO_input",
          "source": "BLOCK_78683974-0032-49b0-8f27-3f607e25909e",
          "target": "PARALLEL_CLOSE_47e34ee6-475f-4a92-b866-d6766f7f8982",
          "sourceHandle": "ENO",
          "targetHandle": "input"
        },
        {
          "id": "e_PARALLEL_OPEN_4234044b-331e-44f5-9431-81132dd96497_BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238__output-down_???",
          "source": "PARALLEL_OPEN_4234044b-331e-44f5-9431-81132dd96497",
          "target": "BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238",
          "sourceHandle": "output-down",
          "targetHandle": "EN"
        },
        {
          "id": "e_PARALLEL_CLOSE_47e34ee6-475f-4a92-b866-d6766f7f8982_right-rail-rung_main_0f89c824-463a-4dcf-8a45-0abaac15d086__output-right_right-rail",
          "source": "PARALLEL_CLOSE_47e34ee6-475f-4a92-b866-d6766f7f8982",
          "target": "right-rail-rung_main_0f89c824-463a-4dcf-8a45-0abaac15d086",
          "sourceHandle": "output-right",
          "targetHandle": "right-rail"
        },
        {
          "id": "e_BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238_BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60__ENO_???",
          "source": "BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238",
          "target": "BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60",
          "sourceHandle": "ENO",
          "targetHandle": "EN"
        },
        {
          "id": "e_BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60_PARALLEL_CLOSE_47e34ee6-475f-4a92-b866-d6766f7f8982__ENO_input-down",
          "source": "BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60",
          "target": "PARALLEL_CLOSE_47e34ee6-475f-4a92-b866-d6766f7f8982",
          "sourceHandle": "ENO",
          "targetHandle": "input-down"
        },
        {
          "id": "e_BLOCK_29b3706c-09b2-4bc6-8228-fb615803693d_VARIABLE_1b7c3f3e-010b-438c-90e4-6881548094f2__OUT_input",
          "source": "BLOCK_29b3706c-09b2-4bc6-8228-fb615803693d",
          "target": "VARIABLE_1b7c3f3e-010b-438c-90e4-6881548094f2",
          "sourceHandle": "OUT",
          "targetHandle": "input"
        },
        {
          "id": "e_VARIABLE_fbea204f-b6b1-4093-a39d-572f9c6ef496_BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9__output_dtUTC",
          "source": "VARIABLE_fbea204f-b6b1-4093-a39d-572f9c6ef496",
          "target": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
          "sourceHandle": "output",
          "targetHandle": "dtUTC"
        },
        {
          "id": "e_BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9_VARIABLE_cb320d6a-8cba-4cac-b8ed-a73a54e45d0f__iYear_input",
          "source": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
          "target": "VARIABLE_cb320d6a-8cba-4cac-b8ed-a73a54e45d0f",
          "sourceHandle": "iYear",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9_VARIABLE_e4a2cff7-7c40-40a4-8f6a-fe44fa53e120__iMonth_input",
          "source": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
          "target": "VARIABLE_e4a2cff7-7c40-40a4-8f6a-fe44fa53e120",
          "sourceHandle": "iMonth",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9_VARIABLE_119a264c-842d-4453-a6fa-12a2fbaacdfe__iDay_input",
          "source": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
          "target": "VARIABLE_119a264c-842d-4453-a6fa-12a2fbaacdfe",
          "sourceHandle": "iDay",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9_VARIABLE_77504960-34ad-4ce4-ac82-cbb889f99bf1__iHour_input",
          "source": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
          "target": "VARIABLE_77504960-34ad-4ce4-ac82-cbb889f99bf1",
          "sourceHandle": "iHour",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9_VARIABLE_f9324f59-0360-4ffa-a6f0-4ddd315e1ac8__iMinute_input",
          "source": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
          "target": "VARIABLE_f9324f59-0360-4ffa-a6f0-4ddd315e1ac8",
          "sourceHandle": "iMinute",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9_VARIABLE_f1e07cba-f942-419e-9f8b-e870317a00ce__iSecond_input",
          "source": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
          "target": "VARIABLE_f1e07cba-f942-419e-9f8b-e870317a00ce",
          "sourceHandle": "iSecond",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9_VARIABLE_9247cd9e-b4a4-414e-b93e-4d0beab1cd21__iWeekday_input",
          "source": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
          "target": "VARIABLE_9247cd9e-b4a4-414e-b93e-4d0beab1cd21",
          "sourceHandle": "iWeekday",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9_VARIABLE_0ae9c662-5bca-4677-8de2-3be63017c6a2__xValid_input",
          "source": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
          "target": "VARIABLE_0ae9c662-5bca-4677-8de2-3be63017c6a2",
          "sourceHandle": "xValid",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9_VARIABLE_f30a951a-3de7-47a8-8d6f-c50895031eb8__lRawDT_input",
          "source": "BLOCK_6c8048f2-abc7-490b-b658-9fc9af8d73c9",
          "target": "VARIABLE_f30a951a-3de7-47a8-8d6f-c50895031eb8",
          "sourceHandle": "lRawDT",
          "targetHandle": "input"
        },
        {
          "id": "e_VARIABLE_83995c73-0bf3-48d5-8b06-e6afa7a2d267_BLOCK_78683974-0032-49b0-8f27-3f607e25909e__output_IN1",
          "source": "VARIABLE_83995c73-0bf3-48d5-8b06-e6afa7a2d267",
          "target": "BLOCK_78683974-0032-49b0-8f27-3f607e25909e",
          "sourceHandle": "output",
          "targetHandle": "IN1"
        },
        {
          "id": "e_VARIABLE_4f6eaeb2-c7e6-4168-bced-e4e514ba49c8_BLOCK_78683974-0032-49b0-8f27-3f607e25909e__output_IN2",
          "source": "VARIABLE_4f6eaeb2-c7e6-4168-bced-e4e514ba49c8",
          "target": "BLOCK_78683974-0032-49b0-8f27-3f607e25909e",
          "sourceHandle": "output",
          "targetHandle": "IN2"
        },
        {
          "id": "e_BLOCK_78683974-0032-49b0-8f27-3f607e25909e_VARIABLE_e98e6388-efd8-4fcf-8323-1d21a78d7dae__OUT_input",
          "source": "BLOCK_78683974-0032-49b0-8f27-3f607e25909e",
          "target": "VARIABLE_e98e6388-efd8-4fcf-8323-1d21a78d7dae",
          "sourceHandle": "OUT",
          "targetHandle": "input"
        },
        {
          "id": "e_VARIABLE_89ffaf83-c8db-466d-bc26-521ce34f9766_BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238__output_IN1",
          "source": "VARIABLE_89ffaf83-c8db-466d-bc26-521ce34f9766",
          "target": "BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238",
          "sourceHandle": "output",
          "targetHandle": "IN1"
        },
        {
          "id": "e_VARIABLE_b6ef30f3-e955-4a38-a4ec-c6da52420d94_BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238__output_IN2",
          "source": "VARIABLE_b6ef30f3-e955-4a38-a4ec-c6da52420d94",
          "target": "BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238",
          "sourceHandle": "output",
          "targetHandle": "IN2"
        },
        {
          "id": "e_BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238_VARIABLE_52f5829c-dda1-4e4d-bd21-4ae74e8e847e__OUT_input",
          "source": "BLOCK_2e20b0b8-49d4-4dcb-9dfb-72674bcd4238",
          "target": "VARIABLE_52f5829c-dda1-4e4d-bd21-4ae74e8e847e",
          "sourceHandle": "OUT",
          "targetHandle": "input"
        },
        {
          "id": "e_VARIABLE_8caeda20-6022-4a76-8f13-eff5bd97a5e7_BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60__output_IN1",
          "source": "VARIABLE_8caeda20-6022-4a76-8f13-eff5bd97a5e7",
          "target": "BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60",
          "sourceHandle": "output",
          "targetHandle": "IN1"
        },
        {
          "id": "e_VARIABLE_6ed2e5bc-c7d4-46d0-9e21-c988fc7e31d8_BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60__output_IN2",
          "source": "VARIABLE_6ed2e5bc-c7d4-46d0-9e21-c988fc7e31d8",
          "target": "BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60",
          "sourceHandle": "output",
          "targetHandle": "IN2"
        },
        {
          "id": "e_BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60_VARIABLE_55c6d84f-85a2-440d-9b98-1a0a556211d5__OUT_input",
          "source": "BLOCK_c8fa2753-481e-40fc-ba30-0bed3f61ec60",
          "target": "VARIABLE_55c6d84f-85a2-440d-9b98-1a0a556211d5",
          "sourceHandle": "OUT",
          "targetHandle": "input"
        }
      ],
      "handleBranches": []
    },
    {
      "id": "rung_main_0f89c824-463a-4dcf-8a45-0abaac15d086",
      "comment": "天気予報取得",
      "defaultBounds": [
        300,
        100
      ],
      "reactFlowViewport": [
        744,
        894
      ],
      "nodes": [
        {
          "id": "left-rail-rung_main_0f89c824-463a-4dcf-8a45-0abaac15d086",
          "type": "powerRail",
          "position": {
            "x": 0,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 3,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "left-rail",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 20,
                "right": -3
              }
            },
            "numericId": "1698726",
            "variant": "left",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_OPEN_8db48968-35e4-4de8-b7c4-b2f30ce17a9f",
          "type": "parallel",
          "position": {
            "x": 23,
            "y": 49
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 23,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 23,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 23,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 50
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "1789370",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "input-top",
              "position": "top",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "output-down",
              "position": "bottom",
              "type": "source",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelCloseReference": "PARALLEL_CLOSE_f1702ff7-2b7c-48cd-8825-a581533d0c1c",
            "type": "open",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "CONTACT_bd6fb4e8-36b5-4057-a053-f86a7f492c36",
          "type": "contact",
          "position": {
            "x": 72,
            "y": 38
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              },
              {
                "glbPosition": {
                  "x": 96,
                  "y": 50
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "variant": "default",
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 96,
                  "y": 50
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 72,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 12
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target",
              "style": {
                "left": -3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 96,
                "y": 50
              },
              "relPosition": {
                "x": 24,
                "y": 12
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source",
              "style": {
                "right": -3
              }
            },
            "numericId": "2331854",
            "variable": {
              "id": "",
              "name": "getFlag",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 24,
          "height": 24,
          "measured": {
            "width": 24,
            "height": 24
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_OPEN_6f8cace0-c35a-46b1-933e-52ee15dd433a",
          "type": "parallel",
          "position": {
            "x": 23,
            "y": 141
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 23,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 142
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 142
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 142
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 23,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 142
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 27,
                  "y": 142
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 142
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 23,
                "y": 142
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 142
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "7116813",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 142
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "input-top",
              "position": "top",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 142
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "output-down",
              "position": "bottom",
              "type": "source",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelCloseReference": "PARALLEL_CLOSE_1c05ac34-3569-4fc0-b48e-ab999282e13a",
            "type": "open",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "CONTACT_765e2955-2101-4e3c-a609-f1012fa17330",
          "type": "contact",
          "position": {
            "x": 72,
            "y": 130
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              },
              {
                "glbPosition": {
                  "x": 96,
                  "y": 142
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "variant": "default",
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 96,
                  "y": 142
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 72,
                "y": 142
              },
              "relPosition": {
                "x": 0,
                "y": 12
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target",
              "style": {
                "left": -3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 96,
                "y": 142
              },
              "relPosition": {
                "x": 24,
                "y": 12
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source",
              "style": {
                "right": -3
              }
            },
            "numericId": "5275053",
            "variable": {
              "id": "",
              "name": "isInitial",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 24,
          "height": 24,
          "measured": {
            "width": 24,
            "height": 24
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_OPEN_c993bdea-f464-4b1b-a6b1-b57c677bc0cd",
          "type": "parallel",
          "position": {
            "x": 23,
            "y": 233
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 23,
                  "y": 234
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 234
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 234
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 234
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 23,
                  "y": 234
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 234
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 27,
                  "y": 234
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 234
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 23,
                "y": 234
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 234
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "9565094",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 234
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "input-top",
              "position": "top",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 234
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "output-down",
              "position": "bottom",
              "type": "source",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelCloseReference": "PARALLEL_CLOSE_19f87a99-a5eb-4b9e-b129-af34b6ec2af8",
            "type": "open",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "CONTACT_fc62e8ee-0bdd-48d4-9ddd-8e19c0beb554",
          "type": "contact",
          "position": {
            "x": 72,
            "y": 222
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 234
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              },
              {
                "glbPosition": {
                  "x": 96,
                  "y": 234
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "variant": "default",
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 234
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 96,
                  "y": 234
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 72,
                "y": 234
              },
              "relPosition": {
                "x": 0,
                "y": 12
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target",
              "style": {
                "left": -3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 96,
                "y": 234
              },
              "relPosition": {
                "x": 24,
                "y": 12
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source",
              "style": {
                "right": -3
              }
            },
            "numericId": "8278396",
            "variable": {
              "id": "",
              "name": "isIdChange",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 24,
          "height": 24,
          "measured": {
            "width": 24,
            "height": 24
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "CONTACT_dd81ea5a-fbe8-472c-8a82-b2766fc73988",
          "type": "contact",
          "position": {
            "x": 72,
            "y": 314
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 326
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              },
              {
                "glbPosition": {
                  "x": 96,
                  "y": 326
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "variant": "default",
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 72,
                  "y": 326
                },
                "relPosition": {
                  "x": 0,
                  "y": 12
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target",
                "style": {
                  "left": -3
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 96,
                  "y": 326
                },
                "relPosition": {
                  "x": 24,
                  "y": 12
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source",
                "style": {
                  "right": -3
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 72,
                "y": 326
              },
              "relPosition": {
                "x": 0,
                "y": 12
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target",
              "style": {
                "left": -3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 96,
                "y": 326
              },
              "relPosition": {
                "x": 24,
                "y": 12
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source",
              "style": {
                "right": -3
              }
            },
            "numericId": "1281662",
            "variable": {
              "id": "",
              "name": "btn_1",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 24,
          "height": 24,
          "measured": {
            "width": 24,
            "height": 24
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_CLOSE_19f87a99-a5eb-4b9e-b129-af34b6ec2af8",
          "type": "parallel",
          "position": {
            "x": 141,
            "y": 233
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 141,
                  "y": 234
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 234
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 234
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 234
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 141,
                  "y": 234
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 234
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 145,
                  "y": 234
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 234
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 141,
                "y": 234
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 145,
                "y": 234
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "6309817",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 145,
                "y": 234
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "input-down",
              "position": "bottom",
              "type": "target",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 145,
                "y": 234
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "output-top",
              "position": "top",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOpenReference": "PARALLEL_OPEN_c993bdea-f464-4b1b-a6b1-b57c677bc0cd",
            "type": "close",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_CLOSE_1c05ac34-3569-4fc0-b48e-ab999282e13a",
          "type": "parallel",
          "position": {
            "x": 141,
            "y": 141
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 141,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 142
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 142
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 142
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 141,
                  "y": 142
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 142
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 145,
                  "y": 142
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 142
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 141,
                "y": 142
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 145,
                "y": 142
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "8360326",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 145,
                "y": 142
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "input-down",
              "position": "bottom",
              "type": "target",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 145,
                "y": 142
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "output-top",
              "position": "top",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOpenReference": "PARALLEL_OPEN_6f8cace0-c35a-46b1-933e-52ee15dd433a",
            "type": "close",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_CLOSE_f1702ff7-2b7c-48cd-8825-a581533d0c1c",
          "type": "parallel",
          "position": {
            "x": 141,
            "y": 49
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 141,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 141,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 145,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 145,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 141,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 145,
                "y": 50
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "9906748",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 145,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "input-down",
              "position": "bottom",
              "type": "target",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 145,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "output-top",
              "position": "top",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOpenReference": "PARALLEL_OPEN_8db48968-35e4-4de8-b7c4-b2f30ce17a9f",
            "type": "close",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "type": "block",
          "position": {
            "x": 265,
            "y": 14
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 265,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "xTrig",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 265,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "udID",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 50
                },
                "relPosition": {
                  "x": 216,
                  "y": 36
                },
                "id": "xBusy",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 90
                },
                "relPosition": {
                  "x": 216,
                  "y": 76
                },
                "id": "xValid",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 130
                },
                "relPosition": {
                  "x": 216,
                  "y": 116
                },
                "id": "xError",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 170
                },
                "relPosition": {
                  "x": 216,
                  "y": 156
                },
                "id": "iErrorCode",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 156,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 210
                },
                "relPosition": {
                  "x": 216,
                  "y": 196
                },
                "id": "xInterlock",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 196,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 250
                },
                "relPosition": {
                  "x": 216,
                  "y": 236
                },
                "id": "iInterlockRemain",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 236,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 290
                },
                "relPosition": {
                  "x": 216,
                  "y": 276
                },
                "id": "udUpdateCount",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 276,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 330
                },
                "relPosition": {
                  "x": 216,
                  "y": 316
                },
                "id": "uiCodeD0",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 316,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 370
                },
                "relPosition": {
                  "x": 216,
                  "y": 356
                },
                "id": "uiCodeD1",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 356,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 410
                },
                "relPosition": {
                  "x": 216,
                  "y": 396
                },
                "id": "uiCodeD2",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 396,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 450
                },
                "relPosition": {
                  "x": 216,
                  "y": 436
                },
                "id": "iTempMaxD0",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 436,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 490
                },
                "relPosition": {
                  "x": 216,
                  "y": 476
                },
                "id": "iTempMaxD1",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 476,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 530
                },
                "relPosition": {
                  "x": 216,
                  "y": 516
                },
                "id": "iTempMaxD2",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 516,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 570
                },
                "relPosition": {
                  "x": 216,
                  "y": 556
                },
                "id": "iRainD0_00",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 556,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 610
                },
                "relPosition": {
                  "x": 216,
                  "y": 596
                },
                "id": "iRainD0_06",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 596,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 650
                },
                "relPosition": {
                  "x": 216,
                  "y": 636
                },
                "id": "iRainD0_12",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 636,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 690
                },
                "relPosition": {
                  "x": 216,
                  "y": 676
                },
                "id": "iRainD0_18",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 676,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 730
                },
                "relPosition": {
                  "x": 216,
                  "y": 716
                },
                "id": "iRainD1_00",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 716,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 770
                },
                "relPosition": {
                  "x": 216,
                  "y": 756
                },
                "id": "iRainD1_06",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 756,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 810
                },
                "relPosition": {
                  "x": 216,
                  "y": 796
                },
                "id": "iRainD1_12",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 796,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 850
                },
                "relPosition": {
                  "x": 216,
                  "y": 836
                },
                "id": "iRainD1_18",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 836,
                  "right": 0
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 265,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "xTrig",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 265,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "udID",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 481,
                  "y": 50
                },
                "relPosition": {
                  "x": 216,
                  "y": 36
                },
                "id": "xBusy",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 90
                },
                "relPosition": {
                  "x": 216,
                  "y": 76
                },
                "id": "xValid",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 130
                },
                "relPosition": {
                  "x": 216,
                  "y": 116
                },
                "id": "xError",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 170
                },
                "relPosition": {
                  "x": 216,
                  "y": 156
                },
                "id": "iErrorCode",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 156,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 210
                },
                "relPosition": {
                  "x": 216,
                  "y": 196
                },
                "id": "xInterlock",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 196,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 250
                },
                "relPosition": {
                  "x": 216,
                  "y": 236
                },
                "id": "iInterlockRemain",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 236,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 290
                },
                "relPosition": {
                  "x": 216,
                  "y": 276
                },
                "id": "udUpdateCount",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 276,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 330
                },
                "relPosition": {
                  "x": 216,
                  "y": 316
                },
                "id": "uiCodeD0",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 316,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 370
                },
                "relPosition": {
                  "x": 216,
                  "y": 356
                },
                "id": "uiCodeD1",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 356,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 410
                },
                "relPosition": {
                  "x": 216,
                  "y": 396
                },
                "id": "uiCodeD2",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 396,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 450
                },
                "relPosition": {
                  "x": 216,
                  "y": 436
                },
                "id": "iTempMaxD0",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 436,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 490
                },
                "relPosition": {
                  "x": 216,
                  "y": 476
                },
                "id": "iTempMaxD1",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 476,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 530
                },
                "relPosition": {
                  "x": 216,
                  "y": 516
                },
                "id": "iTempMaxD2",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 516,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 570
                },
                "relPosition": {
                  "x": 216,
                  "y": 556
                },
                "id": "iRainD0_00",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 556,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 610
                },
                "relPosition": {
                  "x": 216,
                  "y": 596
                },
                "id": "iRainD0_06",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 596,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 650
                },
                "relPosition": {
                  "x": 216,
                  "y": 636
                },
                "id": "iRainD0_12",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 636,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 690
                },
                "relPosition": {
                  "x": 216,
                  "y": 676
                },
                "id": "iRainD0_18",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 676,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 730
                },
                "relPosition": {
                  "x": 216,
                  "y": 716
                },
                "id": "iRainD1_00",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 716,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 770
                },
                "relPosition": {
                  "x": 216,
                  "y": 756
                },
                "id": "iRainD1_06",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 756,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 810
                },
                "relPosition": {
                  "x": 216,
                  "y": 796
                },
                "id": "iRainD1_12",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 796,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 481,
                  "y": 850
                },
                "relPosition": {
                  "x": 216,
                  "y": 836
                },
                "id": "iRainD1_18",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 836,
                  "right": 0
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 265,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 36
              },
              "id": "xTrig",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 36,
                "left": 0
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 481,
                "y": 50
              },
              "relPosition": {
                "x": 216,
                "y": 36
              },
              "id": "xBusy",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 36,
                "right": 0
              }
            },
            "numericId": "9362132",
            "variant": {
              "name": "FB_GetWeather",
              "documentation": "",
              "type": "function-block",
              "variables": [
                {
                  "name": "xTrig",
                  "class": "input",
                  "type": {
                    "value": "BOOL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "立ち上がりで取得開始",
                  "debug": false
                },
                {
                  "name": "udID",
                  "class": "input",
                  "type": {
                    "value": "UDINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "地域ID (6桁。例: 130010=東京, 016010=札幌 は 16010 と入力してよい)",
                  "debug": false
                },
                {
                  "name": "xBusy",
                  "class": "output",
                  "type": {
                    "value": "BOOL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "通信中",
                  "debug": false
                },
                {
                  "name": "xValid",
                  "class": "output",
                  "type": {
                    "value": "BOOL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "直近の取得に成功し、出力が有効",
                  "debug": false
                },
                {
                  "name": "xError",
                  "class": "output",
                  "type": {
                    "value": "BOOL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "直近の取得に失敗",
                  "debug": false
                },
                {
                  "name": "iErrorCode",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "0=正常 1=ID不正 2=HTTPエラー 3=通信失敗/タイムアウト 4=JSON解析失敗",
                  "debug": false
                },
                {
                  "name": "xInterlock",
                  "class": "output",
                  "type": {
                    "value": "BOOL",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "インターロック中 (この間の xTrig は無視)",
                  "debug": false
                },
                {
                  "name": "iInterlockRemain",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "インターロック残り秒",
                  "debug": false
                },
                {
                  "name": "udUpdateCount",
                  "class": "output",
                  "type": {
                    "value": "UDINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "取得成功のたびに +1 (PLC側で変化を見れば完了検出できる)",
                  "debug": false
                },
                {
                  "name": "uiCodeD0",
                  "class": "output",
                  "type": {
                    "value": "UINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "今日",
                  "debug": false
                },
                {
                  "name": "uiCodeD1",
                  "class": "output",
                  "type": {
                    "value": "UINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "明日",
                  "debug": false
                },
                {
                  "name": "uiCodeD2",
                  "class": "output",
                  "type": {
                    "value": "UINT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "明後日",
                  "debug": false
                },
                {
                  "name": "iTempMaxD0",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "今日",
                  "debug": false
                },
                {
                  "name": "iTempMaxD1",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "明日",
                  "debug": false
                },
                {
                  "name": "iTempMaxD2",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "明後日",
                  "debug": false
                },
                {
                  "name": "iRainD0_00",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "今日 0-6時",
                  "debug": false
                },
                {
                  "name": "iRainD0_06",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "今日 6-12時",
                  "debug": false
                },
                {
                  "name": "iRainD0_12",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "今日 12-18時",
                  "debug": false
                },
                {
                  "name": "iRainD0_18",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "今日 18-24時",
                  "debug": false
                },
                {
                  "name": "iRainD1_00",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "明日 0-6時",
                  "debug": false
                },
                {
                  "name": "iRainD1_06",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "明日 6-12時",
                  "debug": false
                },
                {
                  "name": "iRainD1_12",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "明日 12-18時",
                  "debug": false
                },
                {
                  "name": "iRainD1_18",
                  "class": "output",
                  "type": {
                    "value": "INT",
                    "definition": "base-type"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "明日 18-24時",
                  "debug": false
                }
              ]
            },
            "variable": {
              "name": "instGetWeather",
              "class": "local",
              "type": {
                "definition": "derived",
                "value": "FB_GetWeather"
              },
              "location": "",
              "initialValue": null,
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "executionControl": false,
            "lockExecutionControl": false,
            "connectedVariables": [
              {
                "handleId": "xValid",
                "type": "output",
                "variable": {
                  "name": "gApiValid",
                  "class": "external",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  },
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "xError",
                "type": "output",
                "variable": {
                  "name": "gApiError",
                  "class": "external",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  },
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "uiCodeD0",
                "type": "output",
                "variable": {
                  "name": "gWethCode[0]"
                }
              },
              {
                "handleId": "uiCodeD1",
                "type": "output",
                "variable": {
                  "name": "gWethCode[1]"
                }
              },
              {
                "handleId": "uiCodeD2",
                "type": "output",
                "variable": {
                  "name": "gWethCode[2]"
                }
              },
              {
                "handleId": "iTempMaxD0",
                "type": "output",
                "variable": {
                  "name": "gWethTemp[0]"
                }
              },
              {
                "handleId": "iTempMaxD1",
                "type": "output",
                "variable": {
                  "name": "gWethTemp[1]"
                }
              },
              {
                "handleId": "iTempMaxD2",
                "type": "output",
                "variable": {
                  "name": "gWethTemp[2]"
                }
              },
              {
                "handleId": "iRainD0_00",
                "type": "output",
                "variable": {
                  "name": "gWethRain[0]"
                }
              },
              {
                "handleId": "iRainD0_06",
                "type": "output",
                "variable": {
                  "name": "gWethRain[1]"
                }
              },
              {
                "handleId": "iRainD0_12",
                "type": "output",
                "variable": {
                  "name": "gWethRain[2]"
                }
              },
              {
                "handleId": "iRainD0_18",
                "type": "output",
                "variable": {
                  "name": "gWethRain[3]"
                }
              },
              {
                "handleId": "iRainD1_00",
                "type": "output",
                "variable": {
                  "name": "gWethRain[4]"
                }
              },
              {
                "handleId": "iRainD1_06",
                "type": "output",
                "variable": {
                  "name": "gWethRain[5]"
                }
              },
              {
                "handleId": "iRainD1_12",
                "type": "output",
                "variable": {
                  "name": "gWethRain[6]"
                }
              },
              {
                "handleId": "iRainD1_18",
                "type": "output",
                "variable": {
                  "name": "gWethRain[7]"
                }
              },
              {
                "handleId": "udID",
                "type": "input",
                "variable": {
                  "name": "gAreaID",
                  "class": "external",
                  "type": {
                    "definition": "base-type",
                    "value": "UDINT"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "",
                  "debug": true
                }
              }
            ],
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 216,
          "height": 860,
          "measured": {
            "width": 216,
            "height": 860
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "right-rail-rung_main_0f89c824-463a-4dcf-8a45-0abaac15d086",
          "type": "powerRail",
          "position": {
            "x": 741,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                },
                "x": 741
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                }
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 297,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "right-rail",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 20,
                "left": -3
              }
            },
            "numericId": "1909110",
            "variant": "right",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_d9a76549-400b-4e67-987c-3bb171568f24",
          "type": "variable",
          "position": {
            "x": 155,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 315,
                  "y": 90
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 315,
                  "y": 90
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 315,
                "y": 90
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "3490446",
            "variable": {
              "name": "gAreaID",
              "class": "external",
              "type": {
                "definition": "base-type",
                "value": "UDINT"
              },
              "location": "",
              "initialValue": null,
              "documentation": "",
              "debug": true
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "udID",
              "variableType": {
                "name": "udID",
                "class": "input",
                "type": {
                  "value": "UDINT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "地域ID (6桁。例: 130010=東京, 016010=札幌 は 16010 と入力してよい)",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_4ee75e0a-b3f5-4390-be53-9f98f0af23d5",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 90
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "9338449",
            "variable": {
              "name": "gApiValid",
              "class": "external",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "xValid",
              "variableType": {
                "name": "xValid",
                "class": "output",
                "type": {
                  "value": "BOOL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "直近の取得に成功し、出力が有効",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_e29cb2d0-baa1-458f-a580-192b75b24d4b",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 114
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 130
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 130
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 130
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "7321542",
            "variable": {
              "name": "gApiError",
              "class": "external",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "xError",
              "variableType": {
                "name": "xError",
                "class": "output",
                "type": {
                  "value": "BOOL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "直近の取得に失敗",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_9efcd3d3-c698-444e-97e0-5fc9fe5bcede",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 154
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 170
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 170
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 170
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "4471347",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "iErrorCode",
              "variableType": {
                "name": "iErrorCode",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "0=正常 1=ID不正 2=HTTPエラー 3=通信失敗/タイムアウト 4=JSON解析失敗",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_1019eea8-4933-4ad7-b036-8e86b36788cd",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 194
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 210
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 210
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 210
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "2512218",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "xInterlock",
              "variableType": {
                "name": "xInterlock",
                "class": "output",
                "type": {
                  "value": "BOOL",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "インターロック中 (この間の xTrig は無視)",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_ec2611e6-d71a-46b6-a869-bc962062b5a1",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 234
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 250
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 250
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 250
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "1899269",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "iInterlockRemain",
              "variableType": {
                "name": "iInterlockRemain",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "インターロック残り秒",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_bac0905f-64de-4ace-9236-510642ab8a73",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 274
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 290
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 290
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 290
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "3084827",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "udUpdateCount",
              "variableType": {
                "name": "udUpdateCount",
                "class": "output",
                "type": {
                  "value": "UDINT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "取得成功のたびに +1 (PLC側で変化を見れば完了検出できる)",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_ce00fa49-804b-4eb9-bf3a-bcd537575313",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 314
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 330
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 330
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 330
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "786541",
            "variable": {
              "name": "gWethCode[0]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "uiCodeD0",
              "variableType": {
                "name": "uiCodeD0",
                "class": "output",
                "type": {
                  "value": "UINT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "今日",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_ec82999b-9d69-442c-9899-d35c6981e04d",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 354
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 370
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 370
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 370
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "6891033",
            "variable": {
              "name": "gWethCode[1]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "uiCodeD1",
              "variableType": {
                "name": "uiCodeD1",
                "class": "output",
                "type": {
                  "value": "UINT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "明日",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_a1bc4355-9507-4d3e-b5b0-7c3ab5f14e4d",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 394
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 410
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 410
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 410
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "10124326",
            "variable": {
              "name": "gWethCode[2]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "uiCodeD2",
              "variableType": {
                "name": "uiCodeD2",
                "class": "output",
                "type": {
                  "value": "UINT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "明後日",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_069adea1-1e71-4950-830a-ec263ec9497b",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 434
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 450
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 450
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 450
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "3030826",
            "variable": {
              "name": "gWethTemp[0]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "iTempMaxD0",
              "variableType": {
                "name": "iTempMaxD0",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "今日",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_1637747b-8f23-4ee7-a960-aece5af42158",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 474
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 490
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 490
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 490
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "9705586",
            "variable": {
              "name": "gWethTemp[1]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "iTempMaxD1",
              "variableType": {
                "name": "iTempMaxD1",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "明日",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_b5f07097-81eb-40f8-989c-66301a50f478",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 514
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 530
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 530
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 530
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "8006442",
            "variable": {
              "name": "gWethTemp[2]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "iTempMaxD2",
              "variableType": {
                "name": "iTempMaxD2",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "明後日",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_b75ca206-e73a-4eee-afa8-b855cb215036",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 554
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 570
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 570
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 570
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "3744191",
            "variable": {
              "name": "gWethRain[0]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "iRainD0_00",
              "variableType": {
                "name": "iRainD0_00",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "今日 0-6時",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_4fc07c29-95cb-4ada-ab68-dd4ee70cd6a5",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 594
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 610
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 610
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 610
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "3207119",
            "variable": {
              "name": "gWethRain[1]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "iRainD0_06",
              "variableType": {
                "name": "iRainD0_06",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "今日 6-12時",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_7bc9ac46-0818-43d4-b757-853fa4dedb30",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 634
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 650
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 650
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 650
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "6416878",
            "variable": {
              "name": "gWethRain[2]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "iRainD0_12",
              "variableType": {
                "name": "iRainD0_12",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "今日 12-18時",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_56868cc1-6429-4bea-a181-049e080928cd",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 674
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 690
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 690
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 690
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "514537",
            "variable": {
              "name": "gWethRain[3]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "iRainD0_18",
              "variableType": {
                "name": "iRainD0_18",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "今日 18-24時",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_fe947e87-28b2-466b-85b2-2fa851f780c3",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 714
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 730
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 730
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 730
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "10319695",
            "variable": {
              "name": "gWethRain[4]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "iRainD1_00",
              "variableType": {
                "name": "iRainD1_00",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "明日 0-6時",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_66893301-ea49-4fba-af36-274eeb1956ef",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 754
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 770
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 770
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 770
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "6480394",
            "variable": {
              "name": "gWethRain[5]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "iRainD1_06",
              "variableType": {
                "name": "iRainD1_06",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "明日 6-12時",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_0f8813f9-4e97-4008-a082-82e19f9d40a8",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 794
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 810
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 810
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 810
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "2939952",
            "variable": {
              "name": "gWethRain[6]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "iRainD1_12",
              "variableType": {
                "name": "iRainD1_12",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "明日 12-18時",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_61bf63aa-62c4-484d-96da-71fac982c5c5",
          "type": "variable",
          "position": {
            "x": 511,
            "y": 834
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 850
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 511,
                  "y": 850
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 511,
                "y": 850
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "7505777",
            "variable": {
              "name": "gWethRain[7]"
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
              "handleId": "iRainD1_18",
              "variableType": {
                "name": "iRainD1_18",
                "class": "output",
                "type": {
                  "value": "INT",
                  "definition": "base-type"
                },
                "location": "",
                "initialValue": null,
                "documentation": "明日 18-24時",
                "debug": false
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        }
      ],
      "edges": [
        {
          "id": "e_left-rail-rung_main_0f89c824-463a-4dcf-8a45-0abaac15d086_PARALLEL_OPEN_8db48968-35e4-4de8-b7c4-b2f30ce17a9f__left-rail_input",
          "source": "left-rail-rung_main_0f89c824-463a-4dcf-8a45-0abaac15d086",
          "target": "PARALLEL_OPEN_8db48968-35e4-4de8-b7c4-b2f30ce17a9f",
          "sourceHandle": "left-rail",
          "targetHandle": "input"
        },
        {
          "id": "e_PARALLEL_OPEN_8db48968-35e4-4de8-b7c4-b2f30ce17a9f_CONTACT_bd6fb4e8-36b5-4057-a053-f86a7f492c36__output-right_input",
          "source": "PARALLEL_OPEN_8db48968-35e4-4de8-b7c4-b2f30ce17a9f",
          "target": "CONTACT_bd6fb4e8-36b5-4057-a053-f86a7f492c36",
          "sourceHandle": "output-right",
          "targetHandle": "input"
        },
        {
          "id": "e_CONTACT_bd6fb4e8-36b5-4057-a053-f86a7f492c36_PARALLEL_CLOSE_f1702ff7-2b7c-48cd-8825-a581533d0c1c__output_input",
          "source": "CONTACT_bd6fb4e8-36b5-4057-a053-f86a7f492c36",
          "target": "PARALLEL_CLOSE_f1702ff7-2b7c-48cd-8825-a581533d0c1c",
          "sourceHandle": "output",
          "targetHandle": "input"
        },
        {
          "id": "e_PARALLEL_CLOSE_f1702ff7-2b7c-48cd-8825-a581533d0c1c_BLOCK_66830353-efbc-4589-b401-3014b0532e45__output-right_xTrig",
          "source": "PARALLEL_CLOSE_f1702ff7-2b7c-48cd-8825-a581533d0c1c",
          "target": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "sourceHandle": "output-right",
          "targetHandle": "xTrig"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_right-rail-rung_main_0f89c824-463a-4dcf-8a45-0abaac15d086__xBusy_right-rail",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "right-rail-rung_main_0f89c824-463a-4dcf-8a45-0abaac15d086",
          "sourceHandle": "xBusy",
          "targetHandle": "right-rail"
        },
        {
          "id": "e_PARALLEL_OPEN_8db48968-35e4-4de8-b7c4-b2f30ce17a9f_PARALLEL_OPEN_6f8cace0-c35a-46b1-933e-52ee15dd433a__output-down_input-top",
          "source": "PARALLEL_OPEN_8db48968-35e4-4de8-b7c4-b2f30ce17a9f",
          "target": "PARALLEL_OPEN_6f8cace0-c35a-46b1-933e-52ee15dd433a",
          "sourceHandle": "output-down",
          "targetHandle": "input-top"
        },
        {
          "id": "e_CONTACT_765e2955-2101-4e3c-a609-f1012fa17330_PARALLEL_CLOSE_1c05ac34-3569-4fc0-b48e-ab999282e13a__output_input",
          "source": "CONTACT_765e2955-2101-4e3c-a609-f1012fa17330",
          "target": "PARALLEL_CLOSE_1c05ac34-3569-4fc0-b48e-ab999282e13a",
          "sourceHandle": "output",
          "targetHandle": "input"
        },
        {
          "id": "e_PARALLEL_CLOSE_1c05ac34-3569-4fc0-b48e-ab999282e13a_PARALLEL_CLOSE_f1702ff7-2b7c-48cd-8825-a581533d0c1c__output-top_input-down",
          "source": "PARALLEL_CLOSE_1c05ac34-3569-4fc0-b48e-ab999282e13a",
          "target": "PARALLEL_CLOSE_f1702ff7-2b7c-48cd-8825-a581533d0c1c",
          "sourceHandle": "output-top",
          "targetHandle": "input-down"
        },
        {
          "id": "e_PARALLEL_OPEN_6f8cace0-c35a-46b1-933e-52ee15dd433a_CONTACT_765e2955-2101-4e3c-a609-f1012fa17330__output-right_input",
          "source": "PARALLEL_OPEN_6f8cace0-c35a-46b1-933e-52ee15dd433a",
          "target": "CONTACT_765e2955-2101-4e3c-a609-f1012fa17330",
          "sourceHandle": "output-right",
          "targetHandle": "input"
        },
        {
          "id": "e_PARALLEL_OPEN_6f8cace0-c35a-46b1-933e-52ee15dd433a_PARALLEL_OPEN_c993bdea-f464-4b1b-a6b1-b57c677bc0cd__output-down_input-top",
          "source": "PARALLEL_OPEN_6f8cace0-c35a-46b1-933e-52ee15dd433a",
          "target": "PARALLEL_OPEN_c993bdea-f464-4b1b-a6b1-b57c677bc0cd",
          "sourceHandle": "output-down",
          "targetHandle": "input-top"
        },
        {
          "id": "e_PARALLEL_OPEN_c993bdea-f464-4b1b-a6b1-b57c677bc0cd_CONTACT_fc62e8ee-0bdd-48d4-9ddd-8e19c0beb554__output-right_input",
          "source": "PARALLEL_OPEN_c993bdea-f464-4b1b-a6b1-b57c677bc0cd",
          "target": "CONTACT_fc62e8ee-0bdd-48d4-9ddd-8e19c0beb554",
          "sourceHandle": "output-right",
          "targetHandle": "input"
        },
        {
          "id": "e_CONTACT_fc62e8ee-0bdd-48d4-9ddd-8e19c0beb554_PARALLEL_CLOSE_19f87a99-a5eb-4b9e-b129-af34b6ec2af8__output_input",
          "source": "CONTACT_fc62e8ee-0bdd-48d4-9ddd-8e19c0beb554",
          "target": "PARALLEL_CLOSE_19f87a99-a5eb-4b9e-b129-af34b6ec2af8",
          "sourceHandle": "output",
          "targetHandle": "input"
        },
        {
          "id": "e_PARALLEL_OPEN_c993bdea-f464-4b1b-a6b1-b57c677bc0cd_CONTACT_dd81ea5a-fbe8-472c-8a82-b2766fc73988__output-down_input",
          "source": "PARALLEL_OPEN_c993bdea-f464-4b1b-a6b1-b57c677bc0cd",
          "target": "CONTACT_dd81ea5a-fbe8-472c-8a82-b2766fc73988",
          "sourceHandle": "output-down",
          "targetHandle": "input"
        },
        {
          "id": "e_CONTACT_dd81ea5a-fbe8-472c-8a82-b2766fc73988_PARALLEL_CLOSE_19f87a99-a5eb-4b9e-b129-af34b6ec2af8__output_input-down",
          "source": "CONTACT_dd81ea5a-fbe8-472c-8a82-b2766fc73988",
          "target": "PARALLEL_CLOSE_19f87a99-a5eb-4b9e-b129-af34b6ec2af8",
          "sourceHandle": "output",
          "targetHandle": "input-down"
        },
        {
          "id": "e_PARALLEL_CLOSE_19f87a99-a5eb-4b9e-b129-af34b6ec2af8_PARALLEL_CLOSE_1c05ac34-3569-4fc0-b48e-ab999282e13a__output-top_input-down",
          "source": "PARALLEL_CLOSE_19f87a99-a5eb-4b9e-b129-af34b6ec2af8",
          "target": "PARALLEL_CLOSE_1c05ac34-3569-4fc0-b48e-ab999282e13a",
          "sourceHandle": "output-top",
          "targetHandle": "input-down"
        },
        {
          "id": "e_VARIABLE_d9a76549-400b-4e67-987c-3bb171568f24_BLOCK_66830353-efbc-4589-b401-3014b0532e45__output_udID",
          "source": "VARIABLE_d9a76549-400b-4e67-987c-3bb171568f24",
          "target": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "sourceHandle": "output",
          "targetHandle": "udID"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_4ee75e0a-b3f5-4390-be53-9f98f0af23d5__xValid_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_4ee75e0a-b3f5-4390-be53-9f98f0af23d5",
          "sourceHandle": "xValid",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_e29cb2d0-baa1-458f-a580-192b75b24d4b__xError_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_e29cb2d0-baa1-458f-a580-192b75b24d4b",
          "sourceHandle": "xError",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_9efcd3d3-c698-444e-97e0-5fc9fe5bcede__iErrorCode_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_9efcd3d3-c698-444e-97e0-5fc9fe5bcede",
          "sourceHandle": "iErrorCode",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_1019eea8-4933-4ad7-b036-8e86b36788cd__xInterlock_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_1019eea8-4933-4ad7-b036-8e86b36788cd",
          "sourceHandle": "xInterlock",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_ec2611e6-d71a-46b6-a869-bc962062b5a1__iInterlockRemain_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_ec2611e6-d71a-46b6-a869-bc962062b5a1",
          "sourceHandle": "iInterlockRemain",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_bac0905f-64de-4ace-9236-510642ab8a73__udUpdateCount_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_bac0905f-64de-4ace-9236-510642ab8a73",
          "sourceHandle": "udUpdateCount",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_ce00fa49-804b-4eb9-bf3a-bcd537575313__uiCodeD0_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_ce00fa49-804b-4eb9-bf3a-bcd537575313",
          "sourceHandle": "uiCodeD0",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_ec82999b-9d69-442c-9899-d35c6981e04d__uiCodeD1_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_ec82999b-9d69-442c-9899-d35c6981e04d",
          "sourceHandle": "uiCodeD1",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_a1bc4355-9507-4d3e-b5b0-7c3ab5f14e4d__uiCodeD2_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_a1bc4355-9507-4d3e-b5b0-7c3ab5f14e4d",
          "sourceHandle": "uiCodeD2",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_069adea1-1e71-4950-830a-ec263ec9497b__iTempMaxD0_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_069adea1-1e71-4950-830a-ec263ec9497b",
          "sourceHandle": "iTempMaxD0",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_1637747b-8f23-4ee7-a960-aece5af42158__iTempMaxD1_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_1637747b-8f23-4ee7-a960-aece5af42158",
          "sourceHandle": "iTempMaxD1",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_b5f07097-81eb-40f8-989c-66301a50f478__iTempMaxD2_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_b5f07097-81eb-40f8-989c-66301a50f478",
          "sourceHandle": "iTempMaxD2",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_b75ca206-e73a-4eee-afa8-b855cb215036__iRainD0_00_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_b75ca206-e73a-4eee-afa8-b855cb215036",
          "sourceHandle": "iRainD0_00",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_4fc07c29-95cb-4ada-ab68-dd4ee70cd6a5__iRainD0_06_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_4fc07c29-95cb-4ada-ab68-dd4ee70cd6a5",
          "sourceHandle": "iRainD0_06",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_7bc9ac46-0818-43d4-b757-853fa4dedb30__iRainD0_12_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_7bc9ac46-0818-43d4-b757-853fa4dedb30",
          "sourceHandle": "iRainD0_12",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_56868cc1-6429-4bea-a181-049e080928cd__iRainD0_18_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_56868cc1-6429-4bea-a181-049e080928cd",
          "sourceHandle": "iRainD0_18",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_fe947e87-28b2-466b-85b2-2fa851f780c3__iRainD1_00_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_fe947e87-28b2-466b-85b2-2fa851f780c3",
          "sourceHandle": "iRainD1_00",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_66893301-ea49-4fba-af36-274eeb1956ef__iRainD1_06_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_66893301-ea49-4fba-af36-274eeb1956ef",
          "sourceHandle": "iRainD1_06",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_0f8813f9-4e97-4008-a082-82e19f9d40a8__iRainD1_12_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_0f8813f9-4e97-4008-a082-82e19f9d40a8",
          "sourceHandle": "iRainD1_12",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_66830353-efbc-4589-b401-3014b0532e45_VARIABLE_61bf63aa-62c4-484d-96da-71fac982c5c5__iRainD1_18_input",
          "source": "BLOCK_66830353-efbc-4589-b401-3014b0532e45",
          "target": "VARIABLE_61bf63aa-62c4-484d-96da-71fac982c5c5",
          "sourceHandle": "iRainD1_18",
          "targetHandle": "input"
        }
      ],
      "selectedNodes": [],
      "handleBranches": []
    },
    {
      "id": "rung_main_bd36285b-bcc6-4418-a279-c9f9d95bbebb",
      "comment": "天気コード更新",
      "defaultBounds": [
        300,
        100
      ],
      "reactFlowViewport": [
        500,
        318
      ],
      "nodes": [
        {
          "id": "left-rail-rung_main_bd36285b-bcc6-4418-a279-c9f9d95bbebb",
          "type": "powerRail",
          "position": {
            "x": 0,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 3,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "left-rail",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "right": -3
                }
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 3,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "left-rail",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 20,
                "right": -3
              }
            },
            "numericId": "7693607",
            "variant": "left",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_OPEN_db6c4446-afea-43d9-8371-28b7e35aa67e",
          "type": "parallel",
          "position": {
            "x": 23,
            "y": 49
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 23,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 23,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "input-top",
                "position": "top",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 27,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "output-down",
                "position": "bottom",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 23,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 50
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "8502844",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "input-top",
              "position": "top",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 27,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "output-down",
              "position": "bottom",
              "type": "source",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelCloseReference": "PARALLEL_CLOSE_a85b8170-4567-4aab-8f7c-6e8c2ff210f8",
            "type": "open",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497",
          "type": "block",
          "position": {
            "x": 147,
            "y": 14
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 147,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 147,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "IN1",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 147,
                  "y": 130
                },
                "relPosition": {
                  "x": 0,
                  "y": 116
                },
                "id": "IN2",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 237,
                  "y": 50
                },
                "relPosition": {
                  "x": 90,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 237,
                  "y": 90
                },
                "relPosition": {
                  "x": 90,
                  "y": 76
                },
                "id": "OUT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 147,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 147,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "IN1",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 147,
                  "y": 130
                },
                "relPosition": {
                  "x": 0,
                  "y": 116
                },
                "id": "IN2",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 116,
                  "left": 0
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 237,
                  "y": 50
                },
                "relPosition": {
                  "x": 90,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 237,
                  "y": 90
                },
                "relPosition": {
                  "x": 90,
                  "y": 76
                },
                "id": "OUT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 147,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 36
              },
              "id": "EN",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 36,
                "left": 0
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 237,
                "y": 50
              },
              "relPosition": {
                "x": 90,
                "y": 36
              },
              "id": "ENO",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 36,
                "right": 0
              }
            },
            "numericId": "6578373",
            "variant": {
              "name": "NE",
              "type": "function",
              "language": "st",
              "variables": [
                {
                  "name": "EN",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "ENO",
                  "class": "output",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "OUT",
                  "class": "output",
                  "type": {
                    "definition": "base-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "IN1",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "ANY_ELEMENTARY"
                  }
                },
                {
                  "name": "IN2",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "ANY_ELEMENTARY"
                  }
                }
              ],
              "body": "",
              "documentation": "",
              "extensible": true,
              "category": "Comparison"
            },
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "executionControl": true,
            "lockExecutionControl": false,
            "connectedVariables": [
              {
                "handleId": "IN1",
                "type": "input",
                "variable": {
                  "name": "gAreaID",
                  "class": "external",
                  "type": {
                    "definition": "base-type",
                    "value": "UDINT"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "",
                  "debug": true
                }
              },
              {
                "handleId": "IN2",
                "type": "input",
                "variable": {
                  "id": "f858548a-be11-4825-8cc6-66e22d5da482",
                  "name": "preID",
                  "type": {
                    "definition": "base-type",
                    "value": "UDINT"
                  },
                  "class": "local",
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              },
              {
                "handleId": "OUT",
                "type": "output",
                "variable": {
                  "id": "",
                  "name": ""
                }
              }
            ],
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 90,
          "height": 140,
          "measured": {
            "width": 90,
            "height": 140
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "BLOCK_07b92c0b-f464-47b1-943b-ea29a403973f",
          "type": "block",
          "position": {
            "x": 147,
            "y": 198
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 147,
                  "y": 234
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 147,
                  "y": 274
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "IN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 225,
                  "y": 234
                },
                "relPosition": {
                  "x": 78,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 225,
                  "y": 274
                },
                "relPosition": {
                  "x": 78,
                  "y": 76
                },
                "id": "OUT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 147,
                  "y": 234
                },
                "relPosition": {
                  "x": 0,
                  "y": 36
                },
                "id": "EN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "left": 0
                }
              },
              {
                "glbPosition": {
                  "x": 147,
                  "y": 274
                },
                "relPosition": {
                  "x": 0,
                  "y": 76
                },
                "id": "IN",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "left": 0
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 225,
                  "y": 234
                },
                "relPosition": {
                  "x": 78,
                  "y": 36
                },
                "id": "ENO",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 36,
                  "right": 0
                }
              },
              {
                "glbPosition": {
                  "x": 225,
                  "y": 274
                },
                "relPosition": {
                  "x": 78,
                  "y": 76
                },
                "id": "OUT",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 76,
                  "right": 0
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 147,
                "y": 234
              },
              "relPosition": {
                "x": 0,
                "y": 36
              },
              "id": "EN",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 36,
                "left": 0
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 225,
                "y": 234
              },
              "relPosition": {
                "x": 78,
                "y": 36
              },
              "id": "ENO",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 36,
                "right": 0
              }
            },
            "numericId": "575122",
            "variant": {
              "name": "MOVE",
              "type": "function",
              "language": "st",
              "variables": [
                {
                  "name": "EN",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "ENO",
                  "class": "output",
                  "type": {
                    "definition": "generic-type",
                    "value": "BOOL"
                  }
                },
                {
                  "name": "OUT",
                  "class": "output",
                  "type": {
                    "definition": "generic-type",
                    "value": "ANY"
                  }
                },
                {
                  "name": "IN",
                  "class": "input",
                  "type": {
                    "definition": "generic-type",
                    "value": "ANY"
                  }
                }
              ],
              "body": "",
              "documentation": "",
              "extensible": false,
              "category": "Selection"
            },
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "executionControl": true,
            "lockExecutionControl": false,
            "connectedVariables": [
              {
                "handleId": "IN",
                "type": "input",
                "variable": {
                  "name": "gAreaID",
                  "class": "external",
                  "type": {
                    "definition": "base-type",
                    "value": "UDINT"
                  },
                  "location": "",
                  "initialValue": null,
                  "documentation": "",
                  "debug": true
                }
              },
              {
                "handleId": "OUT",
                "type": "output",
                "variable": {
                  "id": "f858548a-be11-4825-8cc6-66e22d5da482",
                  "name": "preID",
                  "type": {
                    "definition": "base-type",
                    "value": "UDINT"
                  },
                  "class": "local",
                  "location": "",
                  "documentation": "",
                  "debug": false
                }
              }
            ],
            "draggable": true,
            "selectable": true,
            "deletable": true
          },
          "width": 78,
          "height": 100,
          "measured": {
            "width": 78,
            "height": 100
          },
          "draggable": true,
          "selectable": true,
          "selected": false,
          "dragging": false
        },
        {
          "id": "PARALLEL_CLOSE_a85b8170-4567-4aab-8f7c-6e8c2ff210f8",
          "type": "parallel",
          "position": {
            "x": 357,
            "y": 49
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 357,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 361,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              },
              {
                "glbPosition": {
                  "x": 361,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 361,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 357,
                  "y": 50
                },
                "relPosition": {
                  "x": 0,
                  "y": 1
                },
                "id": "input",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "left": 3
                }
              },
              {
                "glbPosition": {
                  "x": 361,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 2
                },
                "id": "input-down",
                "position": "bottom",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "bottom": 1
                }
              }
            ],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 361,
                  "y": 50
                },
                "relPosition": {
                  "x": 4,
                  "y": 1
                },
                "id": "output-right",
                "position": "right",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "visibility": "hidden",
                  "right": 3
                }
              },
              {
                "glbPosition": {
                  "x": 361,
                  "y": 50
                },
                "relPosition": {
                  "x": 2,
                  "y": 0
                },
                "id": "output-top",
                "position": "top",
                "type": "source",
                "isConnectable": false,
                "style": {
                  "top": 1
                }
              }
            ],
            "inputConnector": {
              "glbPosition": {
                "x": 357,
                "y": 50
              },
              "relPosition": {
                "x": 0,
                "y": 1
              },
              "id": "input",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "left": 3
              }
            },
            "outputConnector": {
              "glbPosition": {
                "x": 361,
                "y": 50
              },
              "relPosition": {
                "x": 4,
                "y": 1
              },
              "id": "output-right",
              "position": "right",
              "type": "source",
              "isConnectable": false,
              "style": {
                "visibility": "hidden",
                "right": 3
              }
            },
            "numericId": "759261",
            "parallelInputConnector": {
              "glbPosition": {
                "x": 361,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 2
              },
              "id": "input-down",
              "position": "bottom",
              "type": "target",
              "isConnectable": false,
              "style": {
                "bottom": 1
              }
            },
            "parallelOutputConnector": {
              "glbPosition": {
                "x": 361,
                "y": 50
              },
              "relPosition": {
                "x": 2,
                "y": 0
              },
              "id": "output-top",
              "position": "top",
              "type": "source",
              "isConnectable": false,
              "style": {
                "top": 1
              }
            },
            "parallelOpenReference": "PARALLEL_OPEN_db6c4446-afea-43d9-8371-28b7e35aa67e",
            "type": "close",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 4,
          "height": 2,
          "measured": {
            "width": 4,
            "height": 2
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "right-rail-rung_main_bd36285b-bcc6-4418-a279-c9f9d95bbebb",
          "type": "powerRail",
          "position": {
            "x": 497,
            "y": 30
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                },
                "x": 497
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 297,
                  "y": 50
                },
                "relPosition": {
                  "x": 3,
                  "y": 20
                },
                "id": "right-rail",
                "position": "left",
                "type": "target",
                "isConnectable": false,
                "style": {
                  "top": 20,
                  "left": -3
                },
                "x": 540
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 297,
                "y": 50
              },
              "relPosition": {
                "x": 3,
                "y": 20
              },
              "id": "right-rail",
              "position": "left",
              "type": "target",
              "isConnectable": false,
              "style": {
                "top": 20,
                "left": -3
              }
            },
            "numericId": "6686091",
            "variant": "right",
            "variable": {
              "name": ""
            },
            "executionOrder": 0,
            "draggable": false,
            "selectable": false,
            "deletable": false
          },
          "width": 3,
          "height": 40,
          "measured": {
            "width": 3,
            "height": 40
          },
          "draggable": false,
          "selectable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_21ee4446-1546-4e92-a3bc-564f18912514",
          "type": "variable",
          "position": {
            "x": 37,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 197,
                  "y": 90
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 197,
                  "y": 90
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 197,
                "y": 90
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "1635263",
            "variable": {
              "name": "gAreaID",
              "class": "external",
              "type": {
                "definition": "base-type",
                "value": "UDINT"
              },
              "location": "",
              "initialValue": null,
              "documentation": "",
              "debug": true
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497",
              "handleId": "IN1",
              "variableType": {
                "name": "IN1",
                "class": "input",
                "type": {
                  "definition": "generic-type",
                  "value": "ANY_ELEMENTARY"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_a8710e8c-7af7-4bd8-8574-57b207920154",
          "type": "variable",
          "position": {
            "x": 37,
            "y": 114
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 197,
                  "y": 130
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 197,
                  "y": 130
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 197,
                "y": 130
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "3765571",
            "variable": {
              "id": "f858548a-be11-4825-8cc6-66e22d5da482",
              "name": "preID",
              "type": {
                "definition": "base-type",
                "value": "UDINT"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497",
              "handleId": "IN2",
              "variableType": {
                "name": "IN2",
                "class": "input",
                "type": {
                  "definition": "generic-type",
                  "value": "ANY_ELEMENTARY"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_25290075-dc49-4608-8889-6fee3db22ad0",
          "type": "variable",
          "position": {
            "x": 267,
            "y": 74
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 267,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 267,
                  "y": 90
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 267,
                "y": 90
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "9243639",
            "variable": {
              "id": "30280df1-d3d6-4e2d-ba5f-a3a304f86ff5",
              "name": "isIdChange",
              "type": {
                "definition": "base-type",
                "value": "BOOL"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497",
              "handleId": "OUT",
              "variableType": {
                "name": "OUT",
                "class": "output",
                "type": {
                  "definition": "base-type",
                  "value": "BOOL"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_ad9d5b42-7512-4bfd-8951-ab5440ede9ca",
          "type": "variable",
          "position": {
            "x": 37,
            "y": 258
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 197,
                  "y": 274
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "inputHandles": [],
            "outputHandles": [
              {
                "glbPosition": {
                  "x": 197,
                  "y": 274
                },
                "relPosition": {
                  "x": 80,
                  "y": 16
                },
                "id": "output",
                "position": "right",
                "isConnectable": false,
                "type": "source"
              }
            ],
            "outputConnector": {
              "glbPosition": {
                "x": 197,
                "y": 274
              },
              "relPosition": {
                "x": 80,
                "y": 16
              },
              "id": "output",
              "position": "right",
              "isConnectable": false,
              "type": "source"
            },
            "numericId": "1232453",
            "variable": {
              "name": "gAreaID",
              "class": "external",
              "type": {
                "definition": "base-type",
                "value": "UDINT"
              },
              "location": "",
              "initialValue": null,
              "documentation": "",
              "debug": true
            },
            "executionOrder": 0,
            "variant": "input",
            "block": {
              "id": "BLOCK_07b92c0b-f464-47b1-943b-ea29a403973f",
              "handleId": "IN",
              "variableType": {
                "name": "IN",
                "class": "input",
                "type": {
                  "definition": "generic-type",
                  "value": "ANY"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        },
        {
          "id": "VARIABLE_a2f52b67-5f52-4777-9dc1-0ac6ce15050c",
          "type": "variable",
          "position": {
            "x": 255,
            "y": 258
          },
          "width": 80,
          "height": 32,
          "measured": {
            "width": 80,
            "height": 32
          },
          "data": {
            "handles": [
              {
                "glbPosition": {
                  "x": 255,
                  "y": 274
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "inputHandles": [
              {
                "glbPosition": {
                  "x": 255,
                  "y": 274
                },
                "relPosition": {
                  "x": 0,
                  "y": 16
                },
                "id": "input",
                "position": "left",
                "isConnectable": false,
                "type": "target"
              }
            ],
            "outputHandles": [],
            "inputConnector": {
              "glbPosition": {
                "x": 255,
                "y": 274
              },
              "relPosition": {
                "x": 0,
                "y": 16
              },
              "id": "input",
              "position": "left",
              "isConnectable": false,
              "type": "target"
            },
            "numericId": "860651",
            "variable": {
              "id": "f858548a-be11-4825-8cc6-66e22d5da482",
              "name": "preID",
              "type": {
                "definition": "base-type",
                "value": "UDINT"
              },
              "class": "local",
              "location": "",
              "documentation": "",
              "debug": false
            },
            "executionOrder": 0,
            "variant": "output",
            "block": {
              "id": "BLOCK_07b92c0b-f464-47b1-943b-ea29a403973f",
              "handleId": "OUT",
              "variableType": {
                "name": "OUT",
                "class": "output",
                "type": {
                  "definition": "generic-type",
                  "value": "ANY"
                }
              }
            },
            "draggable": false,
            "selectable": true,
            "deletable": false
          },
          "deletable": false,
          "selectable": true,
          "draggable": false,
          "selected": false,
          "dragging": false
        }
      ],
      "edges": [
        {
          "id": "e_left-rail-rung_main_bd36285b-bcc6-4418-a279-c9f9d95bbebb_PARALLEL_OPEN_db6c4446-afea-43d9-8371-28b7e35aa67e__left-rail_input",
          "source": "left-rail-rung_main_bd36285b-bcc6-4418-a279-c9f9d95bbebb",
          "target": "PARALLEL_OPEN_db6c4446-afea-43d9-8371-28b7e35aa67e",
          "sourceHandle": "left-rail",
          "targetHandle": "input"
        },
        {
          "id": "e_BLOCK_07b92c0b-f464-47b1-943b-ea29a403973f_PARALLEL_CLOSE_a85b8170-4567-4aab-8f7c-6e8c2ff210f8__ENO_input-down",
          "source": "BLOCK_07b92c0b-f464-47b1-943b-ea29a403973f",
          "target": "PARALLEL_CLOSE_a85b8170-4567-4aab-8f7c-6e8c2ff210f8",
          "sourceHandle": "ENO",
          "targetHandle": "input-down"
        },
        {
          "id": "e_BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497_PARALLEL_CLOSE_a85b8170-4567-4aab-8f7c-6e8c2ff210f8__ENO_input",
          "source": "BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497",
          "target": "PARALLEL_CLOSE_a85b8170-4567-4aab-8f7c-6e8c2ff210f8",
          "sourceHandle": "ENO",
          "targetHandle": "input"
        },
        {
          "id": "e_PARALLEL_CLOSE_a85b8170-4567-4aab-8f7c-6e8c2ff210f8_right-rail-rung_main_bd36285b-bcc6-4418-a279-c9f9d95bbebb__output-right_right-rail",
          "source": "PARALLEL_CLOSE_a85b8170-4567-4aab-8f7c-6e8c2ff210f8",
          "target": "right-rail-rung_main_bd36285b-bcc6-4418-a279-c9f9d95bbebb",
          "sourceHandle": "output-right",
          "targetHandle": "right-rail"
        },
        {
          "id": "e_PARALLEL_OPEN_db6c4446-afea-43d9-8371-28b7e35aa67e_BLOCK_07b92c0b-f464-47b1-943b-ea29a403973f__output-down_EN",
          "source": "PARALLEL_OPEN_db6c4446-afea-43d9-8371-28b7e35aa67e",
          "target": "BLOCK_07b92c0b-f464-47b1-943b-ea29a403973f",
          "sourceHandle": "output-down",
          "targetHandle": "EN"
        },
        {
          "id": "e_PARALLEL_OPEN_db6c4446-afea-43d9-8371-28b7e35aa67e_BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497__output-right_EN",
          "source": "PARALLEL_OPEN_db6c4446-afea-43d9-8371-28b7e35aa67e",
          "target": "BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497",
          "sourceHandle": "output-right",
          "targetHandle": "EN"
        },
        {
          "id": "e_VARIABLE_21ee4446-1546-4e92-a3bc-564f18912514_BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497__output_IN1",
          "source": "VARIABLE_21ee4446-1546-4e92-a3bc-564f18912514",
          "target": "BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497",
          "sourceHandle": "output",
          "targetHandle": "IN1"
        },
        {
          "id": "e_VARIABLE_a8710e8c-7af7-4bd8-8574-57b207920154_BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497__output_IN2",
          "source": "VARIABLE_a8710e8c-7af7-4bd8-8574-57b207920154",
          "target": "BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497",
          "sourceHandle": "output",
          "targetHandle": "IN2"
        },
        {
          "id": "e_BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497_VARIABLE_25290075-dc49-4608-8889-6fee3db22ad0__OUT_input",
          "source": "BLOCK_b8484ef2-1399-4f81-8d58-e4d8e4d71497",
          "target": "VARIABLE_25290075-dc49-4608-8889-6fee3db22ad0",
          "sourceHandle": "OUT",
          "targetHandle": "input"
        },
        {
          "id": "e_VARIABLE_ad9d5b42-7512-4bfd-8951-ab5440ede9ca_BLOCK_07b92c0b-f464-47b1-943b-ea29a403973f__output_IN",
          "source": "VARIABLE_ad9d5b42-7512-4bfd-8951-ab5440ede9ca",
          "target": "BLOCK_07b92c0b-f464-47b1-943b-ea29a403973f",
          "sourceHandle": "output",
          "targetHandle": "IN"
        },
        {
          "id": "e_BLOCK_07b92c0b-f464-47b1-943b-ea29a403973f_VARIABLE_a2f52b67-5f52-4777-9dc1-0ac6ce15050c__OUT_input",
          "source": "BLOCK_07b92c0b-f464-47b1-943b-ea29a403973f",
          "target": "VARIABLE_a2f52b67-5f52-4777-9dc1-0ac6ce15050c",
          "sourceHandle": "OUT",
          "targetHandle": "input"
        }
      ],
      "selectedNodes": [],
      "handleBranches": []
    }
  ]
}
END_PROGRAM