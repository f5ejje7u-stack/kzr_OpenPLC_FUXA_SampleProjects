FUNCTION_BLOCK FB_GetGamepad
  VAR_OUTPUT
    axis_lx : real := 0.0;
    axis_ly : real := 0.0;
    axis_rx : real := 0.0;
    axis_ry : real := 0.0;
    btn_cross : bool := FALSE;
    btn_circle : bool := FALSE;
    btn_square : bool := FALSE;
    btn_triangle : bool := FALSE;
    btn_l1 : bool := FALSE;
    btn_r1 : bool := FALSE;
    axis_l2 : real := 0.0;
    axis_r2 : real := 0.0;
    dpad_x : sint := 0;
    dpad_y : sint := 0;
    connected : bool := FALSE;
  END_VAR
"""
FB_GetGamepad (pygame 不要版)

Linux の joystick API (/dev/input/js*) を標準ライブラリだけで直接読む。
外部パッケージのインストールは不要。

ボタン・軸番号は Linux カーネルドライバ (hid-playstation / hid-sony) の
DualSense / DualShock4 の割り当て。違うコントローラの場合は
ホスト側で `jstest /dev/input/js0` を実行して番号を確認し、下の定数を直す。
"""
# ↓ この2つは OpenPLC が付け足す共有メモリ処理が使うので消さないこと
from multiprocessing import shared_memory
import struct

import os
import glob
import time
import select
import threading

# ---- 設定 -------------------------------------------------------------
# 環境変数 GAMEPAD_DEVICE でデバイスを固定可能 (例: /dev/input/js0)
DEADZONE = 0.05

# 軸番号 (Linux joydev, PS4/PS5 コントローラ)
AXIS_LX, AXIS_LY = 0, 1
AXIS_L2 = 2
AXIS_RX, AXIS_RY = 3, 4
AXIS_R2 = 5
AXIS_HAT_X, AXIS_HAT_Y = 6, 7

# ボタン番号 (Linux joydev, PS4/PS5 コントローラ)
BTN_CROSS = 0
BTN_CIRCLE = 1
BTN_TRIANGLE = 2
BTN_SQUARE = 3
BTN_L1 = 4
BTN_R1 = 5
# ----------------------------------------------------------------------

# struct js_event { __u32 time; __s16 value; __u8 type; __u8 number; }
_EVENT_FMT = '<IhBB'
_EVENT_SIZE = struct.calcsize(_EVENT_FMT)  # 8 bytes
JS_EVENT_BUTTON = 0x01
JS_EVENT_AXIS = 0x02
JS_EVENT_INIT = 0x80

_lock = threading.Lock()
_thread_running = False

_DEFAULT_STATE = {
    'connected':    False,
    'axis_lx':      0.0,
    'axis_ly':      0.0,
    'axis_rx':      0.0,
    'axis_ry':      0.0,
    'axis_l2':      0.0,
    'axis_r2':      0.0,
    'btn_cross':    False,
    'btn_circle':   False,
    'btn_square':   False,
    'btn_triangle': False,
    'btn_l1':       False,
    'btn_r1':       False,
    'dpad_x':       0,
    'dpad_y':       0,
}
_state = dict(_DEFAULT_STATE)

_AXIS_MAP = {
    AXIS_LX: 'axis_lx',
    AXIS_LY: 'axis_ly',
    AXIS_RX: 'axis_rx',
    AXIS_RY: 'axis_ry',
}
_TRIGGER_MAP = {
    AXIS_L2: 'axis_l2',
    AXIS_R2: 'axis_r2',
}
_BUTTON_MAP = {
    BTN_CROSS:    'btn_cross',
    BTN_CIRCLE:   'btn_circle',
    BTN_SQUARE:   'btn_square',
    BTN_TRIANGLE: 'btn_triangle',
    BTN_L1:       'btn_l1',
    BTN_R1:       'btn_r1',
}


def _apply_deadzone(value, deadzone=DEADZONE):
    if abs(value) < deadzone:
        return 0.0
    return value


def _norm(raw):
    """-32767..32767 → -1.0..1.0"""
    return max(-1.0, min(1.0, raw / 32767.0))


def _sign(raw):
    return (raw > 0) - (raw < 0)


def _find_device():
    path = os.environ.get('GAMEPAD_DEVICE')
    if path:
        return path if os.path.exists(path) else None
    devices = sorted(glob.glob('/dev/input/js*'))
    return devices[0] if devices else None


def _reset_state():
    with _lock:
        _state.update(_DEFAULT_STATE)


def _handle_event(value, etype, number):
    etype &= ~JS_EVENT_INIT  # 初期状態通知も通常イベントとして扱う
    with _lock:
        if etype == JS_EVENT_AXIS:
            if number in _AXIS_MAP:
                _state[_AXIS_MAP[number]] = _apply_deadzone(_norm(value))
            elif number in _TRIGGER_MAP:
                _state[_TRIGGER_MAP[number]] = (_norm(value) + 1.0) / 2.0  # 0~1
            elif number == AXIS_HAT_X:
                _state['dpad_x'] = _sign(value)
            elif number == AXIS_HAT_Y:
                # joydev は上が負・下が正 → PLC側の「下が+」とそのまま一致
                _state['dpad_y'] = _sign(value)
        elif etype == JS_EVENT_BUTTON:
            if number in _BUTTON_MAP:
                _state[_BUTTON_MAP[number]] = bool(value)


def _poll():
    fd = None
    while _thread_running:
        # --- 接続 / 再接続 ---
        if fd is None:
            path = _find_device()
            if path is None:
                time.sleep(1.0)
                continue
            try:
                fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
            except OSError as e:
                print(f'FB_GetGamepad: cannot open {path}: {e}', flush=True)
                time.sleep(1.0)
                continue
            print(f'FB_GetGamepad: connected {path}', flush=True)
            with _lock:
                _state['connected'] = True

        # --- イベント読み取り ---
        try:
            ready, _, _ = select.select([fd], [], [], 0.1)
            if not ready:
                continue
            data = os.read(fd, _EVENT_SIZE * 64)
            if not data:
                raise OSError('device closed')
            for off in range(0, len(data) - _EVENT_SIZE + 1, _EVENT_SIZE):
                _t, value, etype, number = struct.unpack_from(_EVENT_FMT, data, off)
                _handle_event(value, etype, number)
        except BlockingIOError:
            continue
        except OSError as e:
            print(f'FB_GetGamepad: disconnected ({e})', flush=True)
            try:
                os.close(fd)
            except OSError:
                pass
            fd = None
            _reset_state()
            time.sleep(1.0)

    if fd is not None:
        os.close(fd)


def block_init():
    global _thread_running
    _thread_running = True
    t = threading.Thread(target=_poll, daemon=True)
    t.start()
    print('FB_GetGamepad: initialized', flush=True)


def block_loop():
    global connected
    global axis_lx, axis_ly, axis_rx, axis_ry
    global axis_l2, axis_r2
    global btn_cross, btn_circle, btn_square, btn_triangle
    global btn_l1, btn_r1
    global dpad_x, dpad_y

    with _lock:
        connected    = _state['connected']
        axis_lx      = _state['axis_lx']
        axis_ly      = _state['axis_ly']
        axis_rx      = _state['axis_rx']
        axis_ry      = _state['axis_ry']
        axis_l2      = _state['axis_l2']
        axis_r2      = _state['axis_r2']
        btn_cross    = _state['btn_cross']
        btn_circle   = _state['btn_circle']
        btn_square   = _state['btn_square']
        btn_triangle = _state['btn_triangle']
        btn_l1       = _state['btn_l1']
        btn_r1       = _state['btn_r1']
        dpad_x       = _state['dpad_x']
        dpad_y       = _state['dpad_y']

END_FUNCTION_BLOCK