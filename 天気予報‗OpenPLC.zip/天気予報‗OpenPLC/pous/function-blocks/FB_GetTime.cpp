FUNCTION_BLOCK FB_GetTime
  VAR_OUTPUT
  year:UINT;
  month:UINT;
  day:UINT;
  hour:UINT;
  minute:UINT;
  second:UINT;
  END_VAR
/* ================================================================
 *  C/C++ FUNCTION BLOCK
 *
 *  ---------------------------------------------------------------
 *  - This function block runs **in sync** with the PLC runtime.
 *  - The `setup()` function is called once when the block initializes.
 *  - The `loop()` function is called at every PLC scan cycle.
 *  - Block input and output variables declared in the variable table
 *    can be accessed directly by name in this C/C++ code.
 *
 *  This block executes as part of the main PLC process and follows
 *  the configured scan time in the Resources. Use it for real-time
 *  control logic, fast I/O operations, or any C-based algorithms.
 * ================================================================ */

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h> // Library for managing date/time
// Called once when the block is initialized
void setup()
{
}
// Called at every PLC scan cycle
void loop()
{
// Get the current system time
time_t t = time(NULL);
struct tm *tm_info = localtime(&t); // Convert to local time
// Get year, month, day, hour, minute, second
year = tm_info->tm_year + 1900; // tm_year is years since 1900
month = tm_info->tm_mon + 1; // tm_mon is 0-11
day = tm_info->tm_mday; // Day of the month 1-31
hour = tm_info->tm_hour; // 0-23
minute = tm_info->tm_min; // 0-59
second = tm_info->tm_sec; // 0-59
}

END_FUNCTION_BLOCK