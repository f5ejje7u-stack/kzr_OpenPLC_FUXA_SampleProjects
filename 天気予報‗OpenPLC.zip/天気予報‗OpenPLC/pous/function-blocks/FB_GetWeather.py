FUNCTION_BLOCK FB_GetWeather
  VAR_INPUT
    xTrig : BOOL;   //立ち上がりで取得開始
    udID  : UDINT;  //地域ID (6桁。例: 130010=東京, 016010=札幌 は 16010 と入力してよい)
  END_VAR
  VAR_OUTPUT
    //通信
    xBusy            : BOOL;   //通信中
    xValid           : BOOL;   //直近の取得に成功し、出力が有効
    xError           : BOOL;   //直近の取得に失敗
    iErrorCode       : INT;    //0=正常 1=ID不正 2=HTTPエラー 3=通信失敗/タイムアウト 4=JSON解析失敗
    xInterlock       : BOOL;   //インターロック中 (この間の xTrig は無視)
    iInterlockRemain : INT;    //インターロック残り秒
    udUpdateCount    : UDINT;  //取得成功のたびに +1 (PLC側で変化を見れば完了検出できる)

    //天気コード (気象庁アイコン番号 100=晴 200=曇 300=雨 400=雪)  無し=0
    uiCodeD0   : UINT;   //今日
    uiCodeD1   : UINT;   //明日
    uiCodeD2   : UINT;   //明後日

    //最高気温 [0.01℃] (18℃ → 180)  無し=-32768
    iTempMaxD0 : INT;    //今日
    iTempMaxD1 : INT;    //明日
    iTempMaxD2 : INT;    //明後日

    //降水確率 [%]  無し(過去の時間帯など)=-1
    iRainD0_00 : INT;    //今日 0-6時
    iRainD0_06 : INT;    //今日 6-12時
    iRainD0_12 : INT;    //今日 12-18時
    iRainD0_18 : INT;    //今日 18-24時
    iRainD1_00 : INT;    //明日 0-6時
    iRainD1_06 : INT;    //明日 6-12時
    iRainD1_12 : INT;    //明日 12-18時
    iRainD1_18 : INT;    //明日 18-24時
  END_VAR
# ================================================================
# DISCLAIMER: Python Function Block Execution
#
# This block runs asynchronously from the main PLC runtime.
# ---------------------------------------------------------------
# - All variables are shared with the runtime through shared memory.
# - The block_init() function is called once when the block starts.
# - The block_loop() function is called periodically (~100ms).
# - IMPORTANT: This periodic call DOES NOT follow the PLC scan cycle.
#   It is NOT guaranteed that block_loop() will execute once per scan.
#
# Use this block for non-time-critical tasks. For logic that must
# match the PLC scan cycle, use standard IEC 61131-3 function blocks.
# ================================================================

# 天気予報 API (https://weather.tsukumijima.net/) から予報を取得し、
# PLC で扱いやすい型に変換して出力する。標準ライブラリのみ使用。
#
# 出力の D0=今日 D1=明日 D2=明後日
#   uiCodeD0..D2     : UINT  天気コード (気象庁アイコン番号 100=晴 200=曇 300=雨 400=雪)  無し=0
#   iTempMaxD0..D2   : INT   最高気温 [0.01℃] (18℃ → 1800)                              無し=-32768
#   iRainD0_00..D1_18: INT   降水確率 [%] 6時間ごと (_00=0-6時 _06=6-12時 _12=12-18時 _18=18-24時)
#                                                                           無し(過去の時間帯など)=-1

# ↓ この2つは OpenPLC が付け足す共有メモリ処理が使うので消さないこと
from multiprocessing import shared_memory
import struct

import os
import json
import time
import threading
import urllib.request
import urllib.error

# ---- 設定 -------------------------------------------------------------
API_URL = 'https://weather.tsukumijima.net/api/forecast/city/{:06d}'
USER_AGENT = 'OpenPLC-FB_GetWeather/1.0'
TIMEOUT_S = 10

# 送信してから次の送信を許可するまでの最小間隔[秒]。
# PLC側から変更できないようにここで固定している (サーバー保護のため)。
MIN_INTERVAL_S = 60

# 最終送信時刻の保存先。PLCを停止→再開しても(コンテナ内では)インターロックが続く
LAST_SEND_FILE = '/tmp/fb_getweather_last_send'
# ----------------------------------------------------------------------

NO_CODE = 0          # UINT なので 0 を「無し」とする (天気コードは100以上)
NO_TEMP = -32768     # INT の最小値を「無し」とする
NO_RAIN = -1

ERR_OK = 0
ERR_BAD_ID = 1
ERR_HTTP = 2
ERR_NETWORK = 3
ERR_PARSE = 4

_RAIN_SLOTS = (('00', 'T00_06'), ('06', 'T06_12'), ('12', 'T12_18'), ('18', 'T18_24'))

_lock = threading.Lock()
_busy = False
_prev_trig = None          # None = 起動後まだ一度も見ていない
_last_send = 0.0           # time.time() 基準

_WEATHER_DEFAULT = {}
for _d in range(3):
    _WEATHER_DEFAULT[f'uiCodeD{_d}'] = NO_CODE
    _WEATHER_DEFAULT[f'iTempMaxD{_d}'] = NO_TEMP
for _d in range(2):
    for _slot, _key in _RAIN_SLOTS:
        _WEATHER_DEFAULT[f'iRainD{_d}_{_slot}'] = NO_RAIN

_state = {
    'xValid':        False,
    'xError':        False,
    'iErrorCode':    ERR_OK,
    'udUpdateCount': 0,
}
_state.update(_WEATHER_DEFAULT)


# ---- 変換ヘルパ --------------------------------------------------------
def _to_temp(t):
    """{'celsius': '18', ...} or None → INT [0.01℃]"""
    try:
        v = int(round(float(t['celsius']) * 100))
    except (TypeError, KeyError, ValueError):
        return NO_TEMP
    return v if -32767 <= v <= 32767 else NO_TEMP


def _to_rain(s):
    """'10%' / '--%' / None → INT"""
    try:
        v = int(str(s).rstrip('%'))
    except ValueError:
        return NO_RAIN
    return v if 0 <= v <= 100 else NO_RAIN


def _to_code(image):
    """image.url の '.../100.svg' → UINT 100"""
    try:
        name = image['url'].rsplit('/', 1)[-1]
        v = int(name.split('.', 1)[0])
    except (TypeError, KeyError, ValueError, AttributeError):
        return NO_CODE
    return v if 0 < v <= 65535 else NO_CODE


def _parse(data):
    """API の JSON(dict) → 出力値の dict"""
    forecasts = data['forecasts']
    if len(forecasts) < 2:
        raise ValueError('forecasts too short')
    out = dict(_WEATHER_DEFAULT)
    for d in range(3):
        if d >= len(forecasts):
            break
        f = forecasts[d] or {}
        out[f'uiCodeD{d}'] = _to_code(f.get('image'))
        out[f'iTempMaxD{d}'] = _to_temp((f.get('temperature') or {}).get('max'))
        if d < 2:
            rain = f.get('chanceOfRain') or {}
            for slot, key in _RAIN_SLOTS:
                out[f'iRainD{d}_{slot}'] = _to_rain(rain.get(key))
    return out


# ---- インターロック ------------------------------------------------------
def _load_last_send():
    try:
        with open(LAST_SEND_FILE) as fp:
            return float(fp.read().strip())
    except (OSError, ValueError):
        return 0.0


def _save_last_send(t):
    try:
        with open(LAST_SEND_FILE, 'w') as fp:
            fp.write(str(t))
    except OSError:
        pass


def _remain():
    r = MIN_INTERVAL_S - (time.time() - _last_send)
    # 時計が戻った場合も最大 MIN_INTERVAL_S 待てば解除される
    return int(min(max(r, 0.0), MIN_INTERVAL_S) + 0.999)


# ---- 通信 (別スレッド) ---------------------------------------------------
def _set_error(code):
    with _lock:
        _state['xValid'] = False
        _state['xError'] = True
        _state['iErrorCode'] = code


def _fetch(city_id):
    global _busy
    try:
        req = urllib.request.Request(
            API_URL.format(city_id),
            headers={'User-Agent': USER_AGENT},
        )
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT_S) as res:
                body = res.read()
        except urllib.error.HTTPError as e:
            print(f'FB_GetWeather: HTTP {e.code}', flush=True)
            _set_error(ERR_HTTP)
            return
        except Exception as e:  # URLError, timeout, socket error など
            print(f'FB_GetWeather: network error: {e}', flush=True)
            _set_error(ERR_NETWORK)
            return

        try:
            values = _parse(json.loads(body.decode('utf-8')))
        except Exception as e:
            print(f'FB_GetWeather: parse error: {e}', flush=True)
            _set_error(ERR_PARSE)
            return

        with _lock:
            _state.update(values)
            _state['xValid'] = True
            _state['xError'] = False
            _state['iErrorCode'] = ERR_OK
            _state['udUpdateCount'] = (_state['udUpdateCount'] + 1) & 0xFFFFFFFF
        print(f'FB_GetWeather: updated id={city_id:06d} '
              f'code={values["uiCodeD0"]}/{values["uiCodeD1"]}/{values["uiCodeD2"]}', flush=True)
    finally:
        with _lock:
            _busy = False


def _request(city_id):
    """立ち上がり検出時に呼ぶ。インターロック・通信中なら何もしない"""
    global _busy, _last_send
    if not (1 <= city_id <= 999999):
        _set_error(ERR_BAD_ID)
        return
    with _lock:
        if _busy or _remain() > 0:
            return
        _busy = True
        _last_send = time.time()      # 失敗してもインターロックをかける
    _save_last_send(_last_send)
    threading.Thread(target=_fetch, args=(city_id,), daemon=True).start()


# ---- OpenPLC Python FB エントリ ----------------------------------------
def block_init():
    global _last_send
    _last_send = _load_last_send()
    print(f'FB_GetWeather: initialized (min interval {MIN_INTERVAL_S}s)', flush=True)


def block_loop():
    global _prev_trig
    global xBusy, xValid, xError, iErrorCode, xInterlock, iInterlockRemain, udUpdateCount
    global uiCodeD0, uiCodeD1, uiCodeD2
    global iTempMaxD0, iTempMaxD1, iTempMaxD2
    global iRainD0_00, iRainD0_06, iRainD0_12, iRainD0_18
    global iRainD1_00, iRainD1_06, iRainD1_12, iRainD1_18

    trig = bool(xTrig)
    # 起動直後に xTrig が既に TRUE でも送信しない (起動のたびに通信するのを防ぐ)
    if _prev_trig is not None and trig and not _prev_trig:
        _request(int(udID))
    _prev_trig = trig

    with _lock:
        remain = _remain()
        xBusy            = _busy
        xValid           = _state['xValid']
        xError           = _state['xError']
        iErrorCode       = _state['iErrorCode']
        xInterlock       = remain > 0
        iInterlockRemain = remain
        udUpdateCount    = _state['udUpdateCount']

        uiCodeD0   = _state['uiCodeD0']
        uiCodeD1   = _state['uiCodeD1']
        uiCodeD2   = _state['uiCodeD2']
        iTempMaxD0 = _state['iTempMaxD0']
        iTempMaxD1 = _state['iTempMaxD1']
        iTempMaxD2 = _state['iTempMaxD2']

        iRainD0_00 = _state['iRainD0_00']
        iRainD0_06 = _state['iRainD0_06']
        iRainD0_12 = _state['iRainD0_12']
        iRainD0_18 = _state['iRainD0_18']
        iRainD1_00 = _state['iRainD1_00']
        iRainD1_06 = _state['iRainD1_06']
        iRainD1_12 = _state['iRainD1_12']
        iRainD1_18 = _state['iRainD1_18']

END_FUNCTION_BLOCK