FUNCTION_BLOCK FB_UtcToJst
  VAR_INPUT
    dtUTC     : DT;      // 現在時刻 (UTC)
  END_VAR
  VAR_OUTPUT
    iYear     : INT;     // 年 (例: 2026)
    iMonth    : INT;     // 月 1-12
    iDay      : INT;     // 日 1-31
    iHour     : INT;     // 時 0-23
    iMinute   : INT;     // 分 0-59
    iSecond   : INT;     // 秒 0-59
    iWeekday  : INT;     // 曜日 0=日 ... 6=土
    xValid    : BOOL;    // 変換結果が有効 (1970年より前の時刻なら FALSE)
    lRawDT    : LINT;    // 確認用: DT_TO_LINT の生の値
  END_VAR
  VAR CONSTANT
    JST_OFFSET_S : LINT := 32400;   // 9時間 [秒]
  END_VAR
  VAR
    lSec      : LINT;    // JST の経過秒
    lDays     : LINT;    // JST の経過日数
    lSecOfDay : LINT;    // その日の 0:00 からの秒
    z : LINT;
    era : LINT;
    doe : LINT;
    yoe : LINT;
    doy : LINT;
    mp : LINT;
    y : LINT;
    m : LINT;
    d : LINT;
  END_VAR

(*
  FB_UtcToJst
  UTC の DT を日本時間 (JST = UTC+9, サマータイムなし) の年月日・時分秒・曜日に分解する。
  DT_TO_LINT と整数計算のみ使用。
  DT の内部単位 (秒/ミリ秒/マイクロ秒/ナノ秒) は値の桁から自動判定する。
  (1973年〜5000年頃の範囲なら単位ごとの桁が重ならない)
 
  曜日コード: 0=日 1=月 2=火 3=水 4=木 5=金 6=土
  日付計算: Howard Hinnant の civil_from_days (グレゴリオ暦, うるう年対応)
*)
  // 1970-01-01 00:00:00 UTC からの経過値 → 秒
  lRawDT := DT_TO_LINT(dtUTC);
  IF lRawDT >= 100000000000000000 THEN        // ナノ秒
    lSec := lRawDT / 1000000000;
  ELSIF lRawDT >= 100000000000000 THEN        // マイクロ秒
    lSec := lRawDT / 1000000;
  ELSIF lRawDT >= 100000000000 THEN           // ミリ秒
    lSec := lRawDT / 1000;
  ELSE                                        // 秒
    lSec := lRawDT;
  END_IF;
  lSec := lSec + JST_OFFSET_S;
 
  xValid := lSec >= 0;
  IF NOT xValid THEN
    RETURN;
  END_IF;
 
  // 時刻
  lDays     := lSec / 86400;
  lSecOfDay := lSec MOD 86400;
  iHour   := LINT_TO_INT(lSecOfDay / 3600);
  iMinute := LINT_TO_INT((lSecOfDay MOD 3600) / 60);
  iSecond := LINT_TO_INT(lSecOfDay MOD 60);
 
  // 曜日 (1970-01-01 は木曜 = 4)
  iWeekday := LINT_TO_INT((lDays + 4) MOD 7);
 
  // 日付 (3月始まりの暦で計算してから1月始まりに戻す)
  z   := lDays + 719468;
  era := z / 146097;
  doe := z - era * 146097;                                         // 0..146096
  yoe := (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;    // 0..399
  y   := yoe + era * 400;
  doy := doe - (365 * yoe + yoe / 4 - yoe / 100);                  // 0..365
  mp  := (5 * doy + 2) / 153;                                      // 0..11 (0=3月)
  d   := doy - (153 * mp + 2) / 5 + 1;
  IF mp < 10 THEN
    m := mp + 3;
  ELSE
    m := mp - 9;
  END_IF;
  IF m <= 2 THEN
    y := y + 1;
  END_IF;
 
  iYear  := LINT_TO_INT(y);
  iMonth := LINT_TO_INT(m);
  iDay   := LINT_TO_INT(d);

END_FUNCTION_BLOCK